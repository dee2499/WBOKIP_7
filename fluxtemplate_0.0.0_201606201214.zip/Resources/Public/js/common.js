$('body').scrollspy({
        target: '#main-navigation',
        offset: 108
      })
     

     $("#main-navigation .nav-pills li a").on('click', function(e) {
      	$('#main-navigation .nav-pills li a').each(function () {
            $(this).parent('li').removeClass('active');
        })
        $(this).parent('li').addClass('active');

        console.log($(this));
      	
         // prevent default anchor click behavior
         e.preventDefault();
       
         // store hash
         var hash = this.hash;
       
         // animate
         $('html, body').animate({
             scrollTop: $(this.hash).offset().top
           }, 600, function(){
       
             // when done, add hash to url
             // (default click behaviour)
             window.location.hash = hash;
           });
       
      });
      
      
$(document).ready(function(){


	//$('.main-container').addClass('col-xs-push-2');
	$(".googleMap").click(function(){
	$(this).removeClass("disabled");		
	 $( ".alert-success" ).fadeOut( "slow", function() {
			$("div").remove(".alert-success");
		});	
	});

	$(".map-frame-box").click(function(){
	$(this).removeClass("disabled");		
	 $( ".alert-success" ).fadeOut( "slow", function() {
			$("div").remove(".alert-success");
		});	
	});


	$(".leftSection").click(function(){
	$(this).removeClass("disabled");		
	 $( ".alert-success" ).fadeOut( "slow", function() {
			$("div").remove(".alert-success");
		});	
	});


  // Slide out gallery
  //   Grid.init();
  //     $('#og-additems').on( 'click', function() {
  //     var $items = ''; 
  //     Grid.addItems( $items );
  //     return false;
  //   }); 


	$( ".logo img" ).removeAttr("width").removeAttr("height");

	$( ".company-link img" ).removeAttr("width").removeAttr("height");

	$( ".logoimage img" ).removeAttr("width").removeAttr("height");

	$( ".logoimage a" ).addClass("logo");

	$( ".logoimage img" ).addClass("img-responsive");

	$( ".webofficeicons ul" ).addClass("contact-icons");

	$( ".webofficeicons ul li:nth-child(1)" ).addClass("company");

	$( ".webofficeicons ul li:nth-child(2)" ).addClass("email");

	$( ".webofficeicons ul li:nth-child(3)" ).addClass("marker");

	$( ".social-media-icons ul" ).addClass("social-media-icons pull-left");

	$( ".social-media-icons ul li:nth-child(1) a" ).addClass("facebook");

	$( ".social-media-icons ul li:nth-child(2) a" ).addClass("xing");

	$( ".social-media-icons ul li:nth-child(3) a" ).addClass("linkedin");

	$( "section#home p" ).wrapInner( "<big></big>");

	$( "#home-content li" ).clone(false).prependTo( "#navigation-links" );

	$( "#contact-content li" ).clone(false).appendTo( "#navigation-links" );

	$( ".contact-items" ).clone(false).appendTo( ".original-items" );
	$( "#main-navigation #navigation-links li:nth-child(1)" ).addClass("active");
	
    $('.lightbox').magnificPopup({
      type: 'image',
      tLoading: 'Loading image #%curr%...',
      closeOnContentClick: true,
      closeBtnInside: true,
      fixedContentPos: false,
      mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side 
      image: 
      {
        verticalFit: true
      },
      zoom: 
      {
        enabled: true, duration: 300 // don't foget to change the duration also in CSS 
      },
      gallery: 
      { 
        enabled: true, navigateByImgClick: true, preload: [0,1] // Will preload 0 - before current, and 1 after the current image 
      }, 
  });  
  $('.csc-textpic caption').each(function() {
      var a = $(this).text();
      $(this).closest('.lightbox').removeAttr('title');
      $(this).closest('.lightbox').attr('title', '+a+');
  });


	$( "button.toggleMenu" ).click(function() {
    $( ".nav" ).slideToggle( "slow", function() {
      // Animation complete.
    });  
  });

});

function printContent(id){
  str=document.getElementById(id).innerHTML
  newwin=window.open('','printwin','left=100,top=100,width=822,height=800')
  newwin.document.write('<HTML>\n<HEAD>\n')
  newwin.document.write('<TITLE>Print Page</TITLE>\n')
  newwin.document.write('<script src="typo3conf\/ext\/enzensberg\/Resources\/Public\/js\/jquery.min.js" type="text\/javascript"><\/script>\n')
  newwin.document.write('<script>\n')

  newwin.document.write('function chkstate(){\n')
  newwin.document.write('if(document.readyState=="complete"){\n')
  newwin.document.write('window.close()\n')
  newwin.document.write('}\n')
  newwin.document.write('else{\n')
  newwin.document.write('setTimeout("chkstate()",2000)\n')
  newwin.document.write('}\n')
  newwin.document.write('}\n')
  newwin.document.write('function print_win(){\n')
  newwin.document.write('window.print();\n')
  newwin.document.write('chkstate();\n')
  newwin.document.write('}\n')
  newwin.document.write('$(document).ready(function(){ $("iframe").remove();}) \n')
  newwin.document.write('$(document).ready(function(){ $("#contactInfo").remove();}) \n')
  newwin.document.write('<\/script>\n')
  newwin.document.write('</HEAD>\n')
  newwin.document.write('<BODY onload="print_win()" style="margin:20px;">\n')
  newwin.document.write(str)
  newwin.document.write('</BODY>\n')
  newwin.document.write('</HTML>\n')
  newwin.document.close() 
}
