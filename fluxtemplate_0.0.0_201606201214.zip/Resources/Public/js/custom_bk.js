$(document).ready(function(){
    $('.carousel').carousel();
    
    
    
});

$('.cropimg img').resizecrop({
   	  width: '200',
   	  height: '145'
});

	jQuery('.popup').magnificPopup({
          type: 'image',
		   tLoading: 'Loading image #%curr%...',
          closeOnContentClick: true,
          closeBtnInside: true,
          fixedContentPos: false,
          mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
          image: {
            verticalFit: true
          },
          zoom: {
            enabled: true,
            duration: 300 // don't foget to change the duration also in CSS
          },
		   gallery: {
            enabled: true,
            navigateByImgClick: true,
            preload: [0,1] // Will preload 0 - before current, and 1 after the current image
          },
		  
     });  
	 $('.csc-default table').addClass('table date-table table-hover');
	 $('.csc-default table').wrap( '<div class="table-responsive"></div>' );
	 
	$('.csc-textpic .table caption').each(function(){ 
	  var a = $(this).text();
	  $(this).closest( ".popup" ).removeAttr("title");
	  $(this).closest( ".popup" ).attr("title","+a+"); 		
	});
	
        
        