

	function printDiv(divID) {
		
		$("#list-h4").css("width","34%");

		//Get the HTML of div

		var divElements = document.getElementById(divID).innerHTML;

		//Get the HTML of whole page

		var oldPage = document.body.innerHTML;

		//Reset the page's HTML with div's HTML only

		var tt = document.body.innerHTML = 

		  "<html><head><title></title></head><body>" + 

		  divElements + "</body>";

		//Print Page

		window.print();

		//Restore orignal HTML

		document.body.innerHTML = oldPage;
		$("#list-h4").css("width","100%");
	}

	

	function WriteCookie(x)

	{
		// var x = urlParam('tx_property_pi1');
	    var cookie_name = 'merken_btn_'+x;
		var cookieset = get_cookie(cookie_name);
		

		if(cookieset){	

			$("#merken_btn_"+x).css("font-weight","normal");
			$("#merken_btn_"+x).addClass("dilike");
			$("#merken_btn_"+x).removeClass("like");	
			var now = new Date();
		  	now.setMonth( now.getMonth() - 5 ); 
			var expires = "; expires="+now.toGMTString();
			document.cookie = cookie_name + "=" + x + expires +"; path=/ " ;
		   	return false;  
		}else{

			var days = 2;
			if (days) {
				var date = new Date();
				date.setTime(date.getTime()+(days*24*60*60*1000));
				var expires = "; expires="+date.toGMTString();
			}
			else var expires = "";

			$("#merken_btn_"+x).css("font-weight","bold");
			$("#merken_btn_"+x).removeClass("dilike");
			$("#merken_btn_"+x).addClass("like");
			document.cookie = cookie_name + "=" + x + expires +"; path=/ " ;
			return false;
		}
	}

	$( document ).ready(function() {
				
		$('.wishList a').each(function () {
            var y = $(this).attr('id');     
		    var cookie_name = y;	

   	        var cookieset = get_cookie(cookie_name);

			if(cookieset){
				$("#"+y).css("font-weight","bold");
				$("#"+y).addClass("like");
				$("#"+y).removeClass("dilike");
			}else{
				$("#"+y).css("font-weight","normal");
				$("#"+y).addClass("dilike");
				$("#"+y).removeClass("like");
			}
		});

	});

	function urlParam(name){

		var results = new RegExp('[\\?&]' + name + '=([^&#]*)').exec(window.location.href);

		if (results==null){

		   return '0';

		}

		else{

		   return results[1] || 0;

		}
	}

		

function get_cookie(Name) {

  var search = Name + "="

  var returnvalue = "";

  if (document.cookie.length > 0) {

    offset = document.cookie.indexOf(search)

    if (offset != -1) { // if cookie exists

      offset += search.length

      // set index of beginning of value

      end = document.cookie.indexOf(";", offset);

      // set index of end of cookie value

      if (end == -1)

         end = document.cookie.length;

      returnvalue=unescape(document.cookie.substring(offset, end))

      }

   }

  return returnvalue;
}

					

