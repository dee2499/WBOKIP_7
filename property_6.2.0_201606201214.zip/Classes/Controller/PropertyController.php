<?php
namespace TYPO3\Property\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2014 Martin Galler <martin.galler@weboffice.co.at>, Weboffice
 *           Pooja Patel <pooja.patel@webofficeindia.com>, Weboffice
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * PropertyController
 */
class PropertyController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * propertyRepository
	 *
	 * @var \TYPO3\Property\Domain\Repository\PropertyRepository
	 * @inject
	 */
	protected $propertyRepository = NULL;

	/**
	 * propertyTypeRepository
	 *
	 * @var \TYPO3\Property\Domain\Repository\PropertyTypeRepository
	 * @inject
	 */
	protected $propertyTypeRepository = NULL;
	
	public function initializeAction() {
		// Set Storage folder id by request id
		if(TYPO3_MODE === 'BE') {
	 			$this->settings['storageFolder'] = \TYPO3\CMS\Core\Utility\GeneralUtility::_GP('id');
		}
	}

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		if(TYPO3_MODE === 'FE') {
			
			$searchArr = \TYPO3\CMS\Core\Utility\GeneralUtility::_GP('tx_property_property');
			
			if(!empty($searchArr['uid'])){
				$search = $searchArr['uid'];
			}else{
				$search = \TYPO3\CMS\Core\Utility\GeneralUtility::_GP('search');
			}

			$defaultRadius = $this->settings['defaultRadius'];
			$defaultRadius = ($defaultRadius !='') ? $defaultRadius: '200';

			$propertyPrice = $this->propertyRepository->findMinMaxPrice();



			$where= $lat = $lng ='';
			if(isset($search)){
				
				if(!isset($_POST['serach_near_location'])){
					$price_id = array();
					$price_val = array();
					
					$type 	= $_REQUEST['property_type'];
					//$price 	= $_REQUEST['property_price'];
					//$city 	= $_REQUEST['property_city'];								
					$cat 	= $_REQUEST['property_cat'];
					$region = $_REQUEST['property_region'];			
					$distance = $_REQUEST['property_distance'];					
					$amount1 = $_REQUEST['amount1'];
					$amount2 = $_REQUEST['amount2'];	

					$where 	= '';
					$where .= ($type !='') ? ' AND property_type='.$type: '';
					//$where .= ($city !='') ? ' AND city="'.$city.'" ' : '';
					$where .= ($cat !='') ? ' AND object_type='.$cat : '';	
					$where .= ($region !='') ? ' AND (city LIKE "%'.$region.'%" OR plz LIKE "%'.$region.'%")' : '';
					
					/*if($price !=''){
						$pr = explode("-",$price);
						if(count($pr)>0){
							$allPrice = $this->propertyRepository->findAllPrice();						
							foreach($allPrice as $key=>$value){				
								$temp=$this->remove_non_numerics($value['price']);	
								if($temp>=$pr[0] && $temp<=$pr[1]){
									$price_id[$key] = $value['uid'];
									$price_val[$key] =$temp;
								}													
							}												
							$uidArr = implode(",",$price_id);
							$where .= ($uidArr !='') ? ' AND uid IN ('.$uidArr.')' : ' AND uid=0';
						}					
					}*/

					if($amount1!=''){
						//$where .= ' AND price<='.$amount1.' AND price >='.$amount2;
						$where .= ' AND price BETWEEN '.$amount1.' AND '.$amount2;
					}

					if($region){
						$where .= ($distance !='') ? ' HAVING distance < '.$distance : '';
						$c_lat =  $this->get_lat_long($region,'lat');
						$c_lon =  $this->get_lat_long($region,'lon');
					}
				}else{		
				 	$c_lat =  $this->getCurrentLocation('lat');
			 		$c_lon =  $this->getCurrentLocation('lon');		
			 		$where .= ' HAVING distance < '.$defaultRadius;
				}
			}				

			$properties = $this->propertyRepository->findAllData($where,$c_lat,$c_lon);
			


			// $c_lat =  $this->getCurrentLocation('lat');
			// $c_lon =  $this->getCurrentLocation('lon');
			//$properties = $this->propertyRepository->findAllData($where,$c_lat,$c_lon);
			

			foreach($properties as $key => $value){
				$imgGallery = explode(',',$value['images']);
				$properties[$key]['images'] = $imgGallery;
				$properties[$key]['title'] = \TYPO3\CMS\Core\Utility\GeneralUtility::fixed_lgd_cs($properties[$key]['title'],'30');
				$properties[$key]['subtitle'] = \TYPO3\CMS\Core\Utility\GeneralUtility::fixed_lgd_cs($properties[$key]['subtitle'],'150');
			}


			// $propertyPrice[0]['min_p'] = intval($propertyPrice[0]['min_p']);
			// $propertyPrice[0]['max_p'] = intval($propertyPrice[0]['max_p']);

			$this->view->assignMultiple(array(
				'properties' => $properties,
				'propertyPrice' =>$propertyPrice[0]
			));		

		}		
	}

	function get_numerics ($str) {
	    preg_match_all('/\d+/', $str, $matches);

	    echo '<pre>';
	    print_r($matches);
	    echo '</pre>';
	    die();
	    
    	return $matches[0];
	}

	
	public function remove_non_numerics($str)
	{ 
		$temp = trim($str);		
		$string = str_replace('$', '', $temp);
		$string = str_replace('/', '', $string);
		$string = str_replace('€', '', $string);
		$string = str_replace('-', '', $string);
		$string = str_replace('.0000', '', $string);
		$string = str_replace('.000', '', $string);
		$string = str_replace('.00', '', $string);
		$string = str_replace('.0', '', $string);		
		$string = str_replace('.', '', $string);
		$string = str_replace(',', '.', $string);
		//$string = number_format($string, 0, ',', '.');
		$string = round($string);		
		return $string;
	}
	
	public function showAction() { 
		//echo "showaction"; exit;
		if(TYPO3_MODE === 'FE') {


			$uriArr = \TYPO3\CMS\Core\Utility\GeneralUtility::_GP('tx_property_property');
			
			if(!empty($uriArr['uid'])){
				$uid = $uriArr['uid'];
			}else{
				$uid = \TYPO3\CMS\Core\Utility\GeneralUtility::_GP('uid');
			}
			
			$property = $this->propertyRepository->findDataByUid($uid);
			
			if($property[0]['images']){
				$imgGallery = explode(',',$property[0]['images']);
				$property[0]['images'] = $imgGallery;
			}
			if($property[0]['pdf']){
				$pdf = explode(',',$property[0]['pdf']);
				$property[0]['pdf'] = $pdf;
			}
			
			$GLOBALS['TSFE']->page['title'] = $property[0]['title'];
			$GLOBALS['TSFE']->indexedDocTitle = $property[0]['title'];
			

			$property_cat =$property[0]['object_type'];
			$property[0]['object_type'] = $property[0]['object_type'] == '0' ? 'Miete' : 'Kauf';
			
			$property_type = $this->propertyRepository->findPropertTypeByUid($property[0]['property_type']);
			$property[0]['property_type'] = $property_type[0]['title'];
			
			$building_type = $this->propertyRepository->findBuildingtTypeByUid($property[0]['building_type']);
			$property[0]['building_type'] = $building_type[0]['title'];
			
			$nextPageId = $this->propertyRepository->findNextPageId($uid);
			$nextPageId = (!empty($nextPageId))? $nextPageId[0]['uid'] : 0;
			
			$previousPageId = $this->propertyRepository->findPreviousPageId($uid);
			$previousPageId = (!empty($previousPageId))? $previousPageId[0]['uid'] : 0;
		}
		
		$currentUrl = $this->uriBuilder->getRequest()->getRequestUri();
		$baseUrl =  $GLOBALS['TSFE']->baseUrl;
		
		$this->view->assignMultiple(array(
			'baseUrl' => $baseUrl,
			'currentUrl' => $currentUrl,
			'property' => $property[0],
			'nextPageId' => $nextPageId,
			'previousPageId' => $previousPageId,
			'properties', $property[0]
		));		
	}

	public function googlemapAction(){
		 
		
		$arguments = $this->request->getArguments();
		
		$city = urlencode(mb_convert_encoding($arguments['city'], 'UTF-8'));
		$street = urlencode(mb_convert_encoding($arguments['street'], 'UTF-8'));
		$title = $arguments['title'];
		$plz = $arguments['plz'];
		
		$iframe_width = '400px'; 
		$iframe_height = '400px'; 
		
		
		//$address = $street.' '.$city.' '.$plz; 
		$address = $city.' '.$plz; 

		$address = str_replace(" ", "+", $address);

		$json = file_get_contents("http://maps.google.com/maps/api/geocode/json?address=$address");
		$json = json_decode($json);

				
		$lat = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lat'};
		$long = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lng'};
	
		$iframe = '		
			<style>
				.infotext {font-size:14px; padding:10px; color:#fff;float:left; }
				.infotext:after, .infotext:before {top: 100%;left: 50%;border: solid transparent;content: " ";height: 0;width: 0;position: absolute;pointer-events: none;}
				.infotext:after {border-color: rgba(136, 183, 213, 0);border-top-color:#97A619;border-width: 20px;	margin-left: -31px;}
				.infotext:before {border-color: rgba(194, 225, 245, 0);border-top-color: #97A619;}
				.infoBox { margin-top:-99px;text-align:center;background:#97A619 !important;}			
			</style>	
			<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
			<script type="text/javascript" src="http://google-maps-utility-library-v3.googlecode.com/svn/trunk/infobox/src/infobox.js"></script>
			<script type="text/javascript">
			function initialize() {
				var loc, map, marker, infobox;
				
				loc = new google.maps.LatLng('.$lat.', '.$long.');
				
				map = new google.maps.Map(document.getElementById("map"), {
					 zoom: 13,
					 center: loc,
					 mapTypeId: google.maps.MapTypeId.ROADMAP
				});
				
				marker = new google.maps.Marker({
					map: map,
					position: loc,
					visible: true
				});
			
				infobox = new InfoBox({
				  content:\'<div class="infotext">'.trim($title).'</div>\',
					 disableAutoPan: false,
					 pixelOffset: new google.maps.Size(-140, 0),
					 zIndex: null,
					 boxStyle: {
						background: "#cb3725",
						 width: "300px",
						 
					
					},
					closeBoxMargin: "12px 4px 2px 2px",
					closeBoxURL: "http://www.google.com/intl/en_us/mapfiles/close.gif",
					infoBoxClearance: new google.maps.Size(1, 1)
				});
				
				google.maps.event.addListener(marker, \'click\', function() {
					infobox.open(map, this);
					map.panTo(loc);
				});
			}
			google.maps.event.addDomListener(window, \'load\', initialize);
			</script>
			<div id="map" style="width: 100%; height: 100%"></div>
					';

		echo $iframe;	exit;
	}
	public function latestAction() {
		if(TYPO3_MODE === 'FE') {
			$propertyOrder = $this->settings['propertyOrder'];
			$propertyCount = $this->settings['propertyCount'];			
			$properties = $this->propertyRepository->findAllLatestData($propertyOrder,$propertyCount);

			
			foreach($properties as $key => $value){
				$imgGallery = explode(',',$value['images']);
				$properties[$key]['images'] = $imgGallery;
			}
			$this->view->assign('properties', $properties);			
		}		

	}
	public function topAction() {
		if(TYPO3_MODE === 'FE') {

			$propertyID = $this->settings['topProperty'];	
			$where = ' AND uid IN ('.$propertyID.')';

			$c_lat =  $this->getCurrentLocation('lat');
			$c_lon =  $this->getCurrentLocation('lon');

			$properties = $this->propertyRepository->findAllData($where,$c_lat,$c_lon);
			
			foreach($properties as $key => $value){
				$imgGallery = explode(',',$value['images']);
				$properties[$key]['images'] = $imgGallery;
			}
			$this->view->assign('properties', $properties);			
		}		

	}
	public function storelocaterAction() {
		if(TYPO3_MODE === 'FE') {

			$GLOBALS['TSFE']->additionalHeaderData[$this->prefixId] = '
				<link rel="stylesheet" type="text/css" href="typo3conf/ext/property/Resources/Public/Css/locate.css" media="all" />	
				<link rel="stylesheet" href="typo3conf/ext/property/Resources/Public/Css/locate-responsive.css">

			';
			$GLOBALS['TSFE']->additionalFooterData[$this->prefixId] = '
				<script src="https://maps.googleapis.com/maps/api/js?&libraries=geometry,places"></script>
				<!--<script type="text/javascript" src="typo3conf/ext/property/Resources/Public/Js/jquery-1.9.0.min.js"></script>-->
				<script type="text/javascript" src="typo3conf/ext/property/Resources/Public/Js/markerclusterer.js"></script>
				<script type="text/javascript" src="typo3conf/ext/property/Resources/Public/Js/bootstrap.js"></script>
				<script type="text/javascript" src="typo3conf/ext/property/Resources/Public/Js/locate.js" charset="utf-8"></script>
				<script type="text/javascript" src="typo3conf/ext/property/Resources/Public/Js/jquery.sort.js" charset="utf-8"></script>
				<script type="text/javascript" src="typo3conf/ext/property/Resources/Public/Js/jquery.geocomplete.js"></script>
			';

        	$propertyTypes['propertyType'] = $this->propertyTypeRepository->findPropertyType();
			$propertyTypes['city'] = $this->propertyTypeRepository->findPropertyCity();
			foreach($propertyTypes['propertyType'] as $key=>$value){				
				$type_id[] = $value['uid'];
				$type_title[] = $value['title'];				
			}
			$type = array_combine($type_id,$type_title);
			
			$city = array();
			array_walk_recursive($propertyTypes['city'], function($item) use (&$city) {
				$city[] = $item;
			});	
							
			$propertyTypes['propertyType'] = $type;
			$propertyTypes['city'] = $city;
			$propertyTypes['price'] = array(
			  "200-500"=>"200-500",
			  "500-1000"=>"500-1000",
			  "1000-5000"=>"1000-5000",
			  "5000-10000"=>"5000-10000",
			  "10000-20000"=>"10000-20000",
			  "20000-50000"=>"20000-50000",
			  "50000-100000"=>"50000-100000",
			  "100000-500000"=>"100000-500000",
			  "500000-1000000"=>"500000-1000000"
			);

			$filterOption = explode(',',$this->settings['filteroption']);

			foreach($filterOption as $key=>$value){
				if($value==1)$check['propertRentSale'] = 1;
				if($value==2)$check['propertyType'] = 1;
				if($value==3)$check['price'] = 1;
				if($value==4)$check['region'] = 1;
				if($value==5)$check['status'] = 1;				
			}

			$currentUrl = $this->uriBuilder->getRequest()->getRequestUri();
			$baseUrl =  $GLOBALS['TSFE']->baseUrl;

			if (isset($_POST['lan'])) {
	            $msg['currentCity']    = $this->getCurrentLocation('city'); 
	            $msg['CurrentCountry'] = $this->getCurrentLocation('countryCode');
	            $msg['CurrentLat']     = $this->getCurrentLocation('lat');
	            $msg['CurrentLng']     = $this->getCurrentLocation('lon');

	            $msg['enter_fulladdress']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_property_domain_model_property.enter_fulladdress','property');
	            $msg['found_stores']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_property_domain_model_property.found_stores','property');
	            $msg['telephone']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_property_domain_model_property.telephone','property');
	            $msg['email']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_property_domain_model_property.email','property');
	            $msg['website']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_property_domain_model_property.website','property');
	            $msg['streetview']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_property_domain_model_property.streetview','property');
	            $msg['zoom']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_property_domain_model_property.zoom','property');
	            $msg['directions']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_property_domain_model_property.directions','property');
	            $msg['direction_not_found']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_property_domain_model_property.direction_not_found','property');
	            $msg['contactStore']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_property_domain_model_property.contactStore','property');
	          
	            echo json_encode($msg);
	            die;
       		}
        
	    	$where = '';


	        if (isset($_POST['ajax'])) {	        	
	            if (isset($_POST['act']) && $_POST['act'] == 'get_nearby_stores') {
	                if (!isset($_POST['lat']) || !isset($_POST['lng'])) {
	                    echo json_encode(array('success' => 0, 'msg' => 'Coordinate not found'));
	                    die;
	                }
	                
	                $price_id = array();
					$price_val = array();
					
					$type 	= $_REQUEST['property_type'];
					$price 	= $_REQUEST['property_price'];
					$city 	= $_REQUEST['property_city'];								
					$cat 	= $_REQUEST['property_cat'];
					$status = $_REQUEST['property_status'];
					
					
					$where 	= '';
					$where .= ($type !='') ? ' AND property_type='.$type: '';
					$where .= ($city !='') ? ' AND city="'.$city.'" ' : '';
					$where .= ($cat !='') ? ' AND object_type='.$cat : '';	
					$where .= ($status ==1) ? ' AND status='.$status : '';	
					if($price !=''){
						$pr = explode("-",$price);
						if(count($pr)>0){
							$allPrice = $this->propertyRepository->findAllPrice();						
							foreach($allPrice as $key=>$value){				
								$temp=$this->remove_non_numerics($value['price']);	
								if($temp>=$pr[0] && $temp<=$pr[1]){
									$price_id[$key] = $value['uid'];
									$price_val[$key] =$temp;
								}													
							}												
							$uidArr = implode(",",$price_id);
							$where .= ($uidArr !='') ? ' AND uid IN ('.$uidArr.')' : ' AND uid=0';
						}					
					}

	                $data['stores'] = $this->propertyRepository->findAllSearchData($where,$_REQUEST);


	                if (isset($data['stores']) && !empty($data['stores'])) {
	                    $data['success'] = 'yes';
	                } else {
	                    $lable = \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_property_domain_model_property.no_store','property');
	                    $data = array('success' => 0, 'msg' => $lable);
	                }
	                //echo json_stores_list($data); 
       
	                echo json_encode($data);
	            }
	            die;
	        }


	       // $locates = $this->propertyRepository->findAllSearchData($where,$_REQUEST);
	      //  $category = $this->propertyRepository->findAllCat();
	 
			$this->view->assignMultiple(array(
				'baseUrl' 		=> $baseUrl,
				'currentUrl'	=> $currentUrl,
				'propertyTypes' => $propertyTypes,
				'locates'      	=> $locates,
	         	'categories'   	=> $category,              
	          	'settings'    	=> $this->settings,
				'check' 		=> $check
			));			
				
		}
	}

	public function wishlistAction() {
			if(TYPO3_MODE === 'FE') {
				foreach($_COOKIE as $key=>$value){
				   if (strpos($key, 'merken_btn') !== false) {
				        $data[] = $value;// You can access $value or create a new array based off these values
				   }
				}
				$PropertyId = '';
				if($data){
					$PropertyId = implode(',',$data);	
				}
				
							
				$properties = $this->propertyRepository->findAllWishListData($PropertyId);
			
				foreach($properties as $key => $value){
					$imgGallery = explode(',',$value['images']);
					$properties[$key]['images'] = $imgGallery;
				}
				$this->view->assign('properties', $properties);			
			}
	}

	 public function getCurrentLocation($para){
        
      $ip = $_SERVER['REMOTE_ADDR']; 
      $data = @unserialize(file_get_contents('http://ip-api.com/php/'.$ip));
	  if($data && $data['status'] == 'success') {
       return $data[$para];
      }else{     
        if($para=='city'){
            $data['city']='Graz';
        }else if($para == 'countryCode'){
             $data['countryCode']='AT';
        }else if($para == 'lat'){
             $data['lat']='47.516231';
        }else if($para == 'lon'){
             $data['lon']='14.550072';
        }else{

        }
     return $data[$para];        
      }   
   }

   function get_lat_long($address,$lat_long){

    $address = str_replace(" ", "+", $address);
    $json = file_get_contents("http://maps.google.com/maps/api/geocode/json?address=$address&sensor=false");
    $json = json_decode($json);

    $lat = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lat'};
    $long = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lng'};

    if($lat_long=="lat"){
    	return $lat;
    }else{
    	return $long;	
    }
    
}


	

	
}