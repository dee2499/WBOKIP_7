<?php
namespace Woi\Event\Domain\Repository;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Deepak <Deepakvisani@gmail.com>, Woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Events
 */
class EventRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {

	public function event($eventid,$settings){
		
		$time = time();
		
		$field = "e.*,GROUP_CONCAT(DISTINCT(c.title) SEPARATOR ', ') as cat_title, GROUP_CONCAT(DISTINCT(c.uid) SEPARATOR ', ') as categoryID,
					  GROUP_CONCAT(DISTINCT(l.city) SEPARATOR ', ') as city_title,GROUP_CONCAT(l.uid) as locationID,
					  GROUP_CONCAT( concat( '.category-', c.uid ) SEPARATOR '' ) AS catName,
					  GROUP_CONCAT( concat( '.category-', c.uid ) SEPARATOR '' ) AS catTotal";

		$table  = "tx_event_domain_model_event AS e 
						LEFT JOIN tx_event_event_category_mm AS m ON m.uid_local = e.uid 
						LEFT JOIN tx_event_domain_model_category AS c ON m.uid_foreign = c.uid 

						LEFT JOIN tx_event_event_location_mm AS lm ON lm.uid_local = e.uid 
						LEFT JOIN tx_event_domain_model_location AS l ON lm.uid_foreign = l.uid 
						";
		
		$groupBy = " e.uid ";
		
		$where  = " e.deleted=0 AND e.hidden=0 AND e.end_date > e.start_date AND e.end_date >= ".$time." AND e.sys_language_uid IN (-1, " . $GLOBALS['TSFE']->sys_language_uid." )";

		$city = '';
		$search = 0;

		 if(isset($_GET['city']) && trim($_GET['city'])!=""){
			// $where .= " AND l.city LIKE '%".$_GET["city"]."%'";
		 	$city = trim($_GET['city']);
		 	$search = 1;
		 }

		if(isset($settings['storagePID']) && $settings['storagePID']!=""){
					$where .=  " AND e.pid IN (".$settings['storagePID'].") ";
				}

		if($eventid>0){
			if ($GLOBALS['TSFE']->sys_language_uid > 0) {
                	$where = $where.' AND e.l10n_parent = ' . $eventid;
                } 
			else
				{
            		$where = $where." AND e.uid = ".$eventid;
				}
		}
		
		if ($GLOBALS['TSFE']->sys_language_uid > 0) {
                $field2 = ' , e.l10n_parent as uid';
                $id = 'l10n_parent';
            }
        else
            {
                $field2 = ' , e.uid as uid';
                $id = 'uid';
            }

        $field1 = $field . $field2;

		//echo $GLOBALS['TYPO3_DB']->SELECTQuery($field1,$table,$where,$groupBy); die;
		
		$category = $this->categoryList();
		

		$result = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($field1,$table,$where,$groupBy);
		
		$result = $this->FalImage($result, "tx_event_domain_model_event");

		$arr108 = array();


		foreach($result as $key => $value){

			$catArr = $catArr1 = array();

			if(strstr($value['categoryID'],",")){
				$catArr = explode(",",$value['categoryID']);
			}else{
				$catArr[] = $value['categoryID'];
			}

			foreach($catArr as $val){
				$catArr1[$val] = $category[$val]['title'];
			}

			if($search==1){
				if($city != '' &&  strstr($value['city_title'],$city)){
					$arr[$value['uid']] =$value;
					$arr[$value['uid']]['categoryArr'] = $catArr1;
				}
				continue;
			}

			$arr[$value['uid']] =$value;
			$arr[$value['uid']]['categoryArr'] = $catArr1;
		}

		// echo $eventid;

		// echo "<pre>";
		// print_r($arr);
		// die;

		if($eventid>0){

			foreach($arr as $val){
				return $val;
			}
		}
		return $arr;
	}


	public function categoryList(){

 		$data = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('uid, title','tx_event_domain_model_category',"deleted = 0 AND hidden = 0");

		foreach($data as $val){
			$arr[$val['uid']] = $val;
		}
		return $arr;
	}
	

	public function getCity(){

 		$field = "l.uid, l.city";

		$table  = "tx_event_domain_model_event AS e
						LEFT JOIN tx_event_event_location_mm AS lm ON lm.uid_local = e.uid 
						LEFT JOIN tx_event_domain_model_location AS l ON lm.uid_foreign = l.uid ";
		
		$groupBy = " l.city ";
		
		$where  = " e.deleted=0 AND e.hidden=0 AND l.city !=''";

		//echo $GLOBALS['TYPO3_DB']->SELECTQuery($field,$table,$where,$groupBy); die; 

		$result = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($field,$table,$where,$groupBy);

		$arr[''] = "View All";
		
		foreach ($result as $value){

			if(trim($value['city'])!=""){
				
				$arr[$value['city']]=trim($value['city']);
			}
		}

		return $arr;
	}

	



	public function categoryName(){

 		$field = "*, GROUP_CONCAT( concat( '.category-', uid ) SEPARATOR '' ) AS catTotal";

		$table  = "tx_event_domain_model_category";
		
		$groupBy = " uid ";
		
		$where  = " deleted=0 AND hidden=0 AND sys_language_uid IN (-1," . $GLOBALS['TSFE']->sys_language_uid.")";

		//echo $GLOBALS['TYPO3_DB']->SELECTQuery($field,$table,$where,$groupBy); die; 

		$result = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($field,$table,$where,$groupBy);

		return $result;
	}

	// For image
    /**
     * @param $result
     * @param $tablename
     * @param $fieldname
     */
    public function FalImage($result, $tablename = NULL, $fieldname = NULL)
    {
        $where = '';
        if ($tablename != '') {
            $where = ' AND tablenames = "' . $tablename . '"';
        }
        if ($fieldname != '') {
            $where .= ' AND fieldname IN (' . $fieldname . ')';
        }
        foreach ($result as $key => $value) {
            $whr = 'deleted= 0 and hidden = 0 ' . $where . ' AND uid_foreign = ' . $value['uid'];
            $sysimages = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*', 'sys_file_reference', $whr, '', 'sorting_foreign');
            $arr = '';
            foreach ($sysimages as $key1 => $value1) {
                $whr1 = ' uid = ' . $value1['uid_local'];
                $sysimagedetail = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*', 'sys_file', $whr1);
                $arr[$value1['fieldname']][$value1['uid']]['imagepath'] = 'fileadmin' . $sysimagedetail[0]['identifier'];
                $arr[$value1['fieldname']][$value1['uid']]['title'] = $value1['title'];
                $arr[$value1['fieldname']][$value1['uid']]['caption'] = $value1['description'];
            }
            $result[$key]['pictures'] = $arr;
        }
        // echo "<pre>";
        // print_r($result);
        // die;
        return $result;
    }

	
}