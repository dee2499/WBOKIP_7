<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'Woi.' . $_EXTKEY,
	'Event',
	array(
		'Event' => 'list, show',
		'Category' => 'category',
		
	),
	// non-cacheable actions
	array(
		'Event' => '',
		'Category' => '',
		
	)
);
## EXTENSION BUILDER DEFAULTS END TOKEN - Everything BEFORE this line is overwritten with the defaults of the extension builder