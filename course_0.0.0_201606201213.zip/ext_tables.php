<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
	'Typo3.' . $_EXTKEY,
	'Course',
	'Course Booking'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($_EXTKEY, 'Configuration/TypoScript', 'Course booking');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_course_domain_model_course', 'EXT:course/Resources/Private/Language/locallang_csh_tx_course_domain_model_course.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_course_domain_model_course');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_course_domain_model_downloads', 'EXT:course/Resources/Private/Language/locallang_csh_tx_course_domain_model_downloads.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_course_domain_model_downloads');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_course_domain_model_locations', 'EXT:course/Resources/Private/Language/locallang_csh_tx_course_domain_model_locations.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_course_domain_model_locations');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_course_domain_model_category', 'EXT:course/Resources/Private/Language/locallang_csh_tx_course_domain_model_category.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_course_domain_model_category');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_course_domain_model_dates', 'EXT:course/Resources/Private/Language/locallang_csh_tx_course_domain_model_dates.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_course_domain_model_dates');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_course_domain_model_durations', 'EXT:course/Resources/Private/Language/locallang_csh_tx_course_domain_model_durations.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_course_domain_model_durations');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_course_domain_model_datestartend', 'EXT:course/Resources/Private/Language/locallang_csh_tx_course_domain_model_datestartend.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_course_domain_model_datestartend');
