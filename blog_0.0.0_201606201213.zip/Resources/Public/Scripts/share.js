function socialsharing_twitter_click(message)
{
	if (typeof message === 'undefined')
		message = encodeURIComponent(location.href);
		window.open('https://twitter.com/intent/tweet?text=' + message , 'sharertwt', 'toolbar=0,status=0,width=640,height=445');
	}

function socialsharing_facebook_click(message)
{
	window.open('https://www.facebook.com/sharer.php?u=' + encodeURIComponent(location.href)+'&v=1', 'sharer', 'toolbar=0,status=0,width=660,height=445');
}

function socialsharing_google_click(message)
{
	window.open('https://plus.google.com/share?url=' + document.location.href + '&data-prefilltext=' + message, 'sharergplus', 'toolbar=0,status=0,width=660,height=445');
	
	
}

$(document).ready(function() {
  $('#filterOptions li a').click(function() {
    // fetch the class of the clicked item
    var ourClass = $(this).attr('class');

    // reset the active class on all the buttons
    $('#filterOptions li').removeClass('active');
    // update the active state on our clicked button
    $(this).parent().addClass('active');

    if(ourClass == 'all') {
      // show all our items
      $('#ourHolder').children('div.item').show();
    }
    else {
      // hide all elements that don't share ourClass
      $('#ourHolder').children('div:not(.' + ourClass + ')').hide();
      // show all elements that do share ourClass
      $('#ourHolder').children('div.' + ourClass).show();
    }
    return false;
  });
});