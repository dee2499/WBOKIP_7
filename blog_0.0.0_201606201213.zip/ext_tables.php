<?php

if (!defined('TYPO3_MODE')) {

	die('Access denied.');

}



\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(

	'WOI.' . $_EXTKEY,

	'Blog',

	'Blog'

);



\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($_EXTKEY, 'Configuration/TypoScript', 'blog');



$extensionName = strtolower(\TYPO3\CMS\Core\Utility\GeneralUtility::underscoredToUpperCamelCase($_EXTKEY));

$pluginName = strtolower($_EXTKEY);

$pluginSignature = $extensionName.'_'.$pluginName; 



$TCA['tt_content']['types']['list']['subtypes_excludelist'][$pluginSignature] = 'layout,select_key,pages'; 

$TCA['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue($pluginSignature, 'FILE:EXT:'.$_EXTKEY . '/Configuration/FlexForms/flexform_pi1.xml');



\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_blog_domain_model_category', 'EXT:blog/Resources/Private/Language/locallang_csh_tx_blog_domain_model_category.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_blog_domain_model_category');

$GLOBALS['TCA']['tx_blog_domain_model_category'] = array(

	'ctrl' => array(

		'title'	=> 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_category',

		'label' => 'category_name',

		'tstamp' => 'tstamp',

		'crdate' => 'crdate',

		'cruser_id' => 'cruser_id',

		'dividers2tabs' => TRUE,



		'versioningWS' => 2,

		'versioning_followPages' => TRUE,



		'languageField' => 'sys_language_uid',

		'transOrigPointerField' => 'l10n_parent',

		'transOrigDiffSourceField' => 'l10n_diffsource',

		'delete' => 'deleted',

		'enablecolumns' => array(

			'disabled' => 'hidden',

			'starttime' => 'starttime',

			'endtime' => 'endtime',

		),

		'searchFields' => 'category_name,',

		'dynamicConfigFile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY) . 'Configuration/TCA/Category.php',

		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($_EXTKEY) . 'Resources/Public/Icons/tx_blog_domain_model_category.gif'

	),

);



\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_blog_domain_model_user', 'EXT:blog/Resources/Private/Language/locallang_csh_tx_blog_domain_model_user.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_blog_domain_model_user');

$GLOBALS['TCA']['tx_blog_domain_model_user'] = array(

	'ctrl' => array(

		'title'	=> 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_user',

		'label' => 'user_name',

		'tstamp' => 'tstamp',

		'crdate' => 'crdate',

		'cruser_id' => 'cruser_id',

		'dividers2tabs' => TRUE,



		'versioningWS' => 2,

		'versioning_followPages' => TRUE,



		'languageField' => 'sys_language_uid',

		'transOrigPointerField' => 'l10n_parent',

		'transOrigDiffSourceField' => 'l10n_diffsource',

		'delete' => 'deleted',

		'enablecolumns' => array(

			'disabled' => 'hidden',

			'starttime' => 'starttime',

			'endtime' => 'endtime',

		),

		'searchFields' => 'user_name,user_email,',

		'dynamicConfigFile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY) . 'Configuration/TCA/User.php',

		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($_EXTKEY) . 'Resources/Public/Icons/tx_blog_domain_model_user.gif'

	),

);



\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_blog_domain_model_post', 'EXT:blog/Resources/Private/Language/locallang_csh_tx_blog_domain_model_post.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_blog_domain_model_post');

$GLOBALS['TCA']['tx_blog_domain_model_post'] = array(

	'ctrl' => array(

		'title'	=> 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post',

		'label' => 'post_title',

		'tstamp' => 'tstamp',

		'crdate' => 'crdate',

		'cruser_id' => 'cruser_id',

		'dividers2tabs' => TRUE,



		'versioningWS' => 2,

		'versioning_followPages' => TRUE,



		'languageField' => 'sys_language_uid',

		'transOrigPointerField' => 'l10n_parent',

		'transOrigDiffSourceField' => 'l10n_diffsource',

		'delete' => 'deleted',

		'enablecolumns' => array(

			'disabled' => 'hidden',

			'starttime' => 'starttime',

			'endtime' => 'endtime',

		),

		'searchFields' => 'post_title,description,image,date,allow_comments,comment_count,category,author,',

		'dynamicConfigFile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY) . 'Configuration/TCA/Post.php',

		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($_EXTKEY) . 'Resources/Public/Icons/tx_blog_domain_model_post.gif'

	),

);



\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_blog_domain_model_comment', 'EXT:blog/Resources/Private/Language/locallang_csh_tx_blog_domain_model_comment.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_blog_domain_model_comment');

$GLOBALS['TCA']['tx_blog_domain_model_comment'] = array(

	'ctrl' => array(

		'title'	=> 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_comment',

		'label' => 'comment_title',

		'tstamp' => 'tstamp',

		'crdate' => 'crdate',

		'cruser_id' => 'cruser_id',

		'dividers2tabs' => TRUE,



		'versioningWS' => 2,

		'versioning_followPages' => TRUE,



		'languageField' => 'sys_language_uid',

		'transOrigPointerField' => 'l10n_parent',

		'transOrigDiffSourceField' => 'l10n_diffsource',

		'delete' => 'deleted',

		'enablecolumns' => array(

			'disabled' => 'hidden',

			'starttime' => 'starttime',

			'endtime' => 'endtime',

		),

		'searchFields' => 'comment_title,name,email,comment_details,date,approved,post,',

		'dynamicConfigFile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY) . 'Configuration/TCA/Comment.php',

		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($_EXTKEY) . 'Resources/Public/Icons/tx_blog_domain_model_comment.gif'

	),

);





\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_blog_domain_model_replytocomment', 'EXT:blog/Resources/Private/Language/locallang_csh_tx_blog_domain_model_replytocomment.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_blog_domain_model_replytocomment');
$GLOBALS['TCA']['tx_blog_domain_model_replytocomment'] = array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_replytocomment',
		'label' => 'replycomment_title',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,
		'versioningWS' => 2,
		'versioning_followPages' => TRUE,
		'languageField' => 'sys_language_uid',
		'transOrigPointerField' => 'l10n_parent',
		'transOrigDiffSourceField' => 'l10n_diffsource',
		'delete' => 'deleted',
		'enablecolumns' => array(
			'disabled' => 'hidden',
			'starttime' => 'starttime',
			'endtime' => 'endtime',
		),
		'searchFields' => 'replycomment_title,name,email,replycomment_details,date,approved,post,',
		'dynamicConfigFile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY) . 'Configuration/TCA/Replycomment.php',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($_EXTKEY) . 'Resources/Public/Icons/tx_blog_domain_model_replytocomment.gif'
	),
);



\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_blog_domain_model_commentscore', 'EXT:blog/Resources/Private/Language/locallang_csh_tx_blog_domain_model_commentscore.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_blog_domain_model_commentscore');
$GLOBALS['TCA']['tx_blog_domain_model_commentscore'] = array(
		'ctrl' => array(
				'title'	=> 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_commentscore',
				'label' => 'comment',
				'tstamp' => 'tstamp',
				'crdate' => 'crdate',
				'cruser_id' => 'cruser_id',
				'dividers2tabs' => TRUE,
				'versioningWS' => 2,
				'versioning_followPages' => TRUE,
				'languageField' => 'sys_language_uid',
				'transOrigPointerField' => 'l10n_parent',
				'transOrigDiffSourceField' => 'l10n_diffsource',
				'delete' => 'deleted',
				'enablecolumns' => array(
						'disabled' => 'hidden',
						'starttime' => 'starttime',
						'endtime' => 'endtime',
				),
				'searchFields' => 'comment',
				'dynamicConfigFile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY) . 'Configuration/TCA/Commentscore.php',
				'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($_EXTKEY) . 'Resources/Public/Icons/tx_blog_domain_model_commentscore.gif'
		),
);


\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_blog_domain_model_replycommentscore', 'EXT:blog/Resources/Private/Language/locallang_csh_tx_blog_domain_model_replycommentscore.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_blog_domain_model_replycommentscore');
$GLOBALS['TCA']['tx_blog_domain_model_replycommentscore'] = array(
		'ctrl' => array(
				'title'	=> 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_replycommentscore',
				'label' => 'uid',
				'tstamp' => 'tstamp',
				'crdate' => 'crdate',
				'cruser_id' => 'cruser_id',
				'dividers2tabs' => TRUE,
				'versioningWS' => 2,
				'versioning_followPages' => TRUE,
				'languageField' => 'sys_language_uid',
				'transOrigPointerField' => 'l10n_parent',
				'transOrigDiffSourceField' => 'l10n_diffsource',
				'delete' => 'deleted',
				'enablecolumns' => array(
						'disabled' => 'hidden',
						'starttime' => 'starttime',
						'endtime' => 'endtime',
				),
				'searchFields' => 'comment',
				'dynamicConfigFile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY) . 'Configuration/TCA/Replycommentscore.php',
				'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($_EXTKEY) . 'Resources/Public/Icons/tx_blog_domain_model_replycommentscore.gif'
		),
);