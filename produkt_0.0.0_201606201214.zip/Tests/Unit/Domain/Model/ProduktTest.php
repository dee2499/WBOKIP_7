<?php

namespace Maunil\Produkt\Tests\Unit\Domain\Model;

/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 maunil <montu1555@gmail.com>, woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class \Maunil\Produkt\Domain\Model\Produkt.
 *
 * @copyright Copyright belongs to the respective authors
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 * @author maunil <montu1555@gmail.com>
 */
class ProduktTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
	/**
	 * @var \Maunil\Produkt\Domain\Model\Produkt
	 */
	protected $subject = NULL;

	public function setUp()
	{
		$this->subject = new \Maunil\Produkt\Domain\Model\Produkt();
	}

	public function tearDown()
	{
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function getProduktnameReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getProduktname()
		);
	}

	/**
	 * @test
	 */
	public function setProduktnameForStringSetsProduktname()
	{
		$this->subject->setProduktname('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'produktname',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getShortdescriptionReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getShortdescription()
		);
	}

	/**
	 * @test
	 */
	public function setShortdescriptionForStringSetsShortdescription()
	{
		$this->subject->setShortdescription('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'shortdescription',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getPriceReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getPrice()
		);
	}

	/**
	 * @test
	 */
	public function setPriceForStringSetsPrice()
	{
		$this->subject->setPrice('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'price',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getSpecificationReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getSpecification()
		);
	}

	/**
	 * @test
	 */
	public function setSpecificationForStringSetsSpecification()
	{
		$this->subject->setSpecification('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'specification',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getDescriptionReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getDescription()
		);
	}

	/**
	 * @test
	 */
	public function setDescriptionForStringSetsDescription()
	{
		$this->subject->setDescription('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'description',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getDescription2ReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getDescription2()
		);
	}

	/**
	 * @test
	 */
	public function setDescription2ForStringSetsDescription2()
	{
		$this->subject->setDescription2('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'description2',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getImageReturnsInitialValueForFileReference()
	{
		$this->assertEquals(
			NULL,
			$this->subject->getImage()
		);
	}

	/**
	 * @test
	 */
	public function setImageForFileReferenceSetsImage()
	{
		$fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
		$this->subject->setImage($fileReferenceFixture);

		$this->assertAttributeEquals(
			$fileReferenceFixture,
			'image',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getGalleryReturnsInitialValueForFileReference()
	{
		$this->assertEquals(
			NULL,
			$this->subject->getGallery()
		);
	}

	/**
	 * @test
	 */
	public function setGalleryForFileReferenceSetsGallery()
	{
		$fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
		$this->subject->setGallery($fileReferenceFixture);

		$this->assertAttributeEquals(
			$fileReferenceFixture,
			'gallery',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getLinkReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getLink()
		);
	}

	/**
	 * @test
	 */
	public function setLinkForStringSetsLink()
	{
		$this->subject->setLink('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'link',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getSubkategorieReturnsInitialValueForSubcategory()
	{
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getSubkategorie()
		);
	}

	/**
	 * @test
	 */
	public function setSubkategorieForObjectStorageContainingSubcategorySetsSubkategorie()
	{
		$subkategorie = new \Maunil\Produkt\Domain\Model\Subcategory();
		$objectStorageHoldingExactlyOneSubkategorie = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneSubkategorie->attach($subkategorie);
		$this->subject->setSubkategorie($objectStorageHoldingExactlyOneSubkategorie);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneSubkategorie,
			'subkategorie',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addSubkategorieToObjectStorageHoldingSubkategorie()
	{
		$subkategorie = new \Maunil\Produkt\Domain\Model\Subcategory();
		$subkategorieObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$subkategorieObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($subkategorie));
		$this->inject($this->subject, 'subkategorie', $subkategorieObjectStorageMock);

		$this->subject->addSubkategorie($subkategorie);
	}

	/**
	 * @test
	 */
	public function removeSubkategorieFromObjectStorageHoldingSubkategorie()
	{
		$subkategorie = new \Maunil\Produkt\Domain\Model\Subcategory();
		$subkategorieObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$subkategorieObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($subkategorie));
		$this->inject($this->subject, 'subkategorie', $subkategorieObjectStorageMock);

		$this->subject->removeSubkategorie($subkategorie);

	}
}
