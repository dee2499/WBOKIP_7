<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'Maunil.' . $_EXTKEY,
	'Produkt',
	array(
		'Produkt' => 'list, show',
		
	),
	// non-cacheable actions
	array(
		'Kategorie' => '',
		'Subcategory' => '',
		'Produkt' => '',
		
	)
);

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'Maunil.' . $_EXTKEY,
	'Produktcategory',
	array(
		'Subcategory' => 'list, show',
		
	),
	// non-cacheable actions
	array(
		'Kategorie' => '',
		'Subcategory' => '',
		'Produkt' => '',
		
	)
);
