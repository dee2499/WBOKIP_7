<?php
namespace Maunil\Produkt\Domain\Repository;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 maunil <montu1555@gmail.com>, woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Produkts
 */
class ProduktRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
    public function getCategory(){
    	$field = '* , GROUP_CONCAT( concat( \'cat_\', uid ) SEPARATOR \' \' ) AS catClass';
		$table = "tx_produkt_domain_model_kategorie";
		$where = ' hidden = 0 AND deleted = 0 ';
		$groupBy = ' uid ';
		$cat  =  $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where ,$groupBy);
		//$data = $this->FalImage($cat, 'tx_produkt_domain_model_kategorie');

		return $cat;
		
    }
    // For subcategory
    /**
     * @param $sid
     * @param $settings
     */
    public function getSubCategory($sid,$settings){


        $field = 's.* , GROUP_CONCAT( concat( \'cat_\', k.uid ) SEPARATOR \' \' ) AS subcatClass';
        $table = "tx_produkt_domain_model_subcategory AS s LEFT JOIN tx_produkt_domain_model_kategorie AS k ON s.kategorie = k.uid";

        if(isset($sid)){
            $where ="s.hidden = 0 AND s.deleted = 0 AND s.uid=".$sid;
        }else{
            $where ="s.hidden = 0 AND s.deleted = 0";
        }
        $groupBy = 's.uid ';
        //echo $subcat  =  $this->getDBHandle()->SELECTquery($field, $table, $where ,$groupBy); die;
        $subcat  =  $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where ,$groupBy);
        $subcat = $this->FalImage($subcat, 'tx_produkt_domain_model_subcategory');

        return $subcat;
        
       
    }


 
     /**
     * @param $sid
     * @param $produktid
     * @param $settings
     */
	public function getProduct($sid,$produktid,$settings){
		$field = "p.*";

		//$table = "tx_produkt_domain_model_produkt AS p LEFT JOIN ";
        //$field = 'p.*,GROUP_CONCAT(s.title SEPARATOR \', \' ) as sub_categories' . $field2;
        $table = 'tx_produkt_domain_model_produkt AS p 

                        LEFT JOIN tx_produkt_produkt_subcategory_mm AS m ON m.uid_local = p.uid 
                        LEFT JOIN tx_produkt_domain_model_subcategory AS s ON m.uid_foreign = s.uid';
		if(isset($sid)){
            $where = " p.hidden = 0 AND p.deleted = 0  AND s.uid = ".$sid;    
        }else{
            if(isset($produktid)){
                $wh = " AND p.uid = ".$produktid;
            }
            $where = " p.hidden = 0 AND p.deleted = 0 ".$wh;   
        }
		$groupBy = ' p.uid ';
        //echo $produkt  =  $this->getDBHandle()->SELECTquery($field, $table, $where ,$groupBy); die;
		$produkt  =  $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where ,$groupBy);
        $produkt = $this->FalImage($produkt, 'tx_produkt_domain_model_produkt');
        $produkt =  $this->subcategory_mm($produkt);
        // echo "<pre>";
        // print_r($produkt);
        // die;
        return $produkt;
	}


        /**
     * @param $produkt
     */
    public function subcategory_mm($produkt){
        $select = 'tx_produkt_domain_model_subcategory.*';
        $local_table = 'tx_produkt_domain_model_produkt';
        $mm_table = 'tx_produkt_produkt_subcategory_mm';
        $foreign_table ='tx_produkt_domain_model_subcategory';
        $groupBy = '';
        $orderBy = '';
        foreach ($produkt as $key => $value) {
            $whereClause = ' AND tx_produkt_domain_model_produkt.uid=' . $value['uid'];
            //echo $res = $GLOBALS['TYPO3_DB']->SELECT_mm_query ($select, $local_table, $mm_table, $foreign_table, $whereClause, $groupBy= '', $orderBy= '', $limit= ''); exit;
            $res = $GLOBALS['TYPO3_DB']->exec_SELECT_mm_query($select, $local_table, $mm_table, $foreign_table, $whereClause, $groupBy = '', $orderBy = '', $limit = '');
            $arr = '';
            $i=1;
            $count = $GLOBALS['TYPO3_DB']->sql_num_rows($res);
            while ($row = $GLOBALS['TYPO3_DB']->sql_fetch_assoc($res)) {
                // echo "<pre>";
                // print_r($row);
                // die;
                $comma = ($i==$count) ? '' : ',';
                $arr['cat_title'] .=  $row['subcategorytitle']. $comma;
                $arr['cat_uid'] .= $row['uid'] . $comma;
                $i++;
            }
            $produkt[$key]['SubCategoryName'] = $arr;
        }
        return $produkt;

    }


	// For image
    /**
     * @param $result
     * @param $tablename
     * @param $fieldname
     */
    public function FalImage($result, $tablename = NULL, $fieldname = NULL)
    {
        //   echo "<pre>";
        //   print_r($result);
        //   die;
        $where = '';
        if ($tablename != '') {
            $where = ' AND tablenames = "' . $tablename . '"';
        }
        if ($fieldname != '') {
            $where .= ' AND fieldname IN (' . $fieldname . ')';
        }
        foreach ($result as $key => $value) {
           //  echo "<pre>";
           // print_r($value);
           // die;
            $whr = 'deleted= 0 and hidden = 0 ' . $where . ' AND uid_foreign = ' . $value['uid'];

           //echo $sysimages = $GLOBALS['TYPO3_DB']->SELECTquery('*', 'sys_file_reference', $whr, '', 'sorting_foreign');  die();
           
            $sysimages = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*', 'sys_file_reference', $whr, '', 'sorting_foreign');
            $arr = '';
            foreach ($sysimages as $key1 => $value1) {
                $whr1 = ' uid = ' . $value1['uid_local'];
                $sysimagedetail = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*', 'sys_file', $whr1);
                $arr[$value1['fieldname']][$value1['uid']]['imagepath'] = 'fileadmin' . $sysimagedetail[0]['identifier'];
                $arr[$value1['fieldname']][$value1['uid']]['title'] = $value1['title'];
                $arr[$value1['fieldname']][$value1['uid']]['caption'] = $value1['description'];
            }
            $result[$key]['pictures'] = $arr;
        }
        // echo "<pre>";
        // print_r($result);
        // die;
        return $result;
    }

	/**
	 * getDBHandle
	 *
	 * @return
	 */
	public function getDBHandle()
	{
		return $GLOBALS['TYPO3_DB'];
	}
}