<?php
namespace Maunil\Produkt\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 maunil <montu1555@gmail.com>, woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Kategorie
 */
class Kategorie extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * kategoriename
     *
     * @var string
     */
    protected $kategoriename = '';
    
    /**
     * shortdescription
     *
     * @var string
     */
    protected $shortdescription = '';
    
    /**
     * image
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    protected $image = null;
    
    /**
     * Returns the kategoriename
     *
     * @return string $kategoriename
     */
    public function getKategoriename()
    {
        return $this->kategoriename;
    }
    
    /**
     * Sets the kategoriename
     *
     * @param string $kategoriename
     * @return void
     */
    public function setKategoriename($kategoriename)
    {
        $this->kategoriename = $kategoriename;
    }
    
    /**
     * Returns the shortdescription
     *
     * @return string $shortdescription
     */
    public function getShortdescription()
    {
        return $this->shortdescription;
    }
    
    /**
     * Sets the shortdescription
     *
     * @param string $shortdescription
     * @return void
     */
    public function setShortdescription($shortdescription)
    {
        $this->shortdescription = $shortdescription;
    }
    
    /**
     * Returns the image
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     */
    public function getImage()
    {
        return $this->image;
    }
    
    /**
     * Sets the image
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     * @return void
     */
    public function setImage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $image)
    {
        $this->image = $image;
    }

}