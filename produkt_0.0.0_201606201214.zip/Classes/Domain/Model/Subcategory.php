<?php
namespace Maunil\Produkt\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 maunil <montu1555@gmail.com>, woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Subcategory
 */
class Subcategory extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * subcategorytitle
     *
     * @var string
     */
    protected $subcategorytitle = '';
    
    /**
     * shortDescription
     *
     * @var string
     */
    protected $shortDescription = '';
    
    /**
     * image
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    protected $image = null;
    
    /**
     * kategorie
     *
     * @var \Maunil\Produkt\Domain\Model\Kategorie
     */
    protected $kategorie = null;
    
    /**
     * Returns the subcategorytitle
     *
     * @return string $subcategorytitle
     */
    public function getSubcategorytitle()
    {
        return $this->subcategorytitle;
    }
    
    /**
     * Sets the subcategorytitle
     *
     * @param string $subcategorytitle
     * @return void
     */
    public function setSubcategorytitle($subcategorytitle)
    {
        $this->subcategorytitle = $subcategorytitle;
    }
    
    /**
     * Returns the shortDescription
     *
     * @return string $shortDescription
     */
    public function getShortDescription()
    {
        return $this->shortDescription;
    }
    
    /**
     * Sets the shortDescription
     *
     * @param string $shortDescription
     * @return void
     */
    public function setShortDescription($shortDescription)
    {
        $this->shortDescription = $shortDescription;
    }
    
    /**
     * Returns the image
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     */
    public function getImage()
    {
        return $this->image;
    }
    
    /**
     * Sets the image
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     * @return void
     */
    public function setImage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $image)
    {
        $this->image = $image;
    }
    
    /**
     * Returns the kategorie
     *
     * @return \Maunil\Produkt\Domain\Model\Kategorie $kategorie
     */
    public function getKategorie()
    {
        return $this->kategorie;
    }
    
    /**
     * Sets the kategorie
     *
     * @param \Maunil\Produkt\Domain\Model\Kategorie $kategorie
     * @return void
     */
    public function setKategorie(\Maunil\Produkt\Domain\Model\Kategorie $kategorie)
    {
        $this->kategorie = $kategorie;
    }

}