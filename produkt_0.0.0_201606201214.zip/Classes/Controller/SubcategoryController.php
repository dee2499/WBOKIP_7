<?php
namespace Maunil\Produkt\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 maunil <montu1555@gmail.com>, woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * SubcategoryController
 */
class SubcategoryController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * subcategoryRepository
     *
     * @var \Maunil\Produkt\Domain\Repository\SubcategoryRepository
     * @inject
     */
    protected $subcategoryRepository = NULL;
    
    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $subcategories = $this->subcategoryRepository->findAll();
        $this->view->assign('subcategories', $subcategories);
        
        $Category = $this->subcategoryRepository->getCategory();        
        $this->view->assign('Category', $Category);

        $subCategory = $this->subcategoryRepository->getSubCategory($sid,$settings);        
        $this->view->assign('subCategory', $subCategory);

        $produkts = $this->subcategoryRepository->getProduct();
         $this->view->assign('produkts', $produkts);
         $this->includeAdditionalData();
    }
    
    /**
     * action show
     *
     * @param \Maunil\Produkt\Domain\Model\Subcategory $subcategory
     * @return void
     */
    public function showAction(\Maunil\Produkt\Domain\Model\Subcategory $subcategory)
    {
        $this->view->assign('subcategory', $subcategory);
    }
      /**
     * includeAdditionalData
     *
     * @return
     */
    function includeAdditionalData() {
        $additionalfooterData = '
        <link rel="stylesheet" href="typo3conf/ext/produkt/Resources/Public/Css/internal.css" type="text/css" media="all" /><link rel="stylesheet" href="typo3conf/ext/produkt/Resources/Public/Css/bootstrap.css"><link rel="stylesheet" href="typo3conf/ext/produkt/Resources/Public/Css/product.css" type="text/css" media="all" />';
        $additionalheaderData .= '
        <script src="typo3conf/ext/produkt/Resources/Public/Js/product.js" type="text/javascript"></script>
        <script src="typo3conf/ext/produkt/Resources/Public/Js/jssor.slider.min.js" type="text/javascript"></script>
        <script src="typo3conf/ext/produkt/Resources/Public/Js/jssor.slider.debug.js" type="text/javascript"></script>
        <script src="typo3conf/ext/produkt/Resources/Public/Js/internal.js" type="text/javascript"></script>
        <script src="typo3conf/ext/produkt/Resources/Public/Js/jquery-1.11.3.min.js"></script>
        <script src="typo3conf/ext/produkt/Resources/Public/Js/bootstrap.min.js"></script>';
        $GLOBALS['TSFE']->additionalFooterData['9996'] = $additionalfooterData;
        $GLOBALS['TSFE']->additionalHeaderData['9669'] = $additionalheaderData;
    }

}