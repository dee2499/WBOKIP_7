<?php
namespace JS\JsTeam\Tests\Unit\Controller;
/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 Jainish Senjailya <j>
 *  			
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class JS\JsTeam\Controller\SubCategoryController.
 *
 * @author Jainish Senjailya <j>
 */
class SubCategoryControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase {

	/**
	 * @var \JS\JsTeam\Controller\SubCategoryController
	 */
	protected $subject = NULL;

	protected function setUp() {
		$this->subject = $this->getMock('JS\\JsTeam\\Controller\\SubCategoryController', array('redirect', 'forward', 'addFlashMessage'), array(), '', FALSE);
	}

	protected function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function listActionFetchesAllSubCategoriesFromRepositoryAndAssignsThemToView() {

		$allSubCategories = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array(), array(), '', FALSE);

		$subCategoryRepository = $this->getMock('JS\\JsTeam\\Domain\\Repository\\SubCategoryRepository', array('findAll'), array(), '', FALSE);
		$subCategoryRepository->expects($this->once())->method('findAll')->will($this->returnValue($allSubCategories));
		$this->inject($this->subject, 'subCategoryRepository', $subCategoryRepository);

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('subCategories', $allSubCategories);
		$this->inject($this->subject, 'view', $view);

		$this->subject->listAction();
	}

	/**
	 * @test
	 */
	public function showActionAssignsTheGivenSubCategoryToView() {
		$subCategory = new \JS\JsTeam\Domain\Model\SubCategory();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$this->inject($this->subject, 'view', $view);
		$view->expects($this->once())->method('assign')->with('subCategory', $subCategory);

		$this->subject->showAction($subCategory);
	}

	/**
	 * @test
	 */
	public function newActionAssignsTheGivenSubCategoryToView() {
		$subCategory = new \JS\JsTeam\Domain\Model\SubCategory();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('newSubCategory', $subCategory);
		$this->inject($this->subject, 'view', $view);

		$this->subject->newAction($subCategory);
	}

	/**
	 * @test
	 */
	public function createActionAddsTheGivenSubCategoryToSubCategoryRepository() {
		$subCategory = new \JS\JsTeam\Domain\Model\SubCategory();

		$subCategoryRepository = $this->getMock('JS\\JsTeam\\Domain\\Repository\\SubCategoryRepository', array('add'), array(), '', FALSE);
		$subCategoryRepository->expects($this->once())->method('add')->with($subCategory);
		$this->inject($this->subject, 'subCategoryRepository', $subCategoryRepository);

		$this->subject->createAction($subCategory);
	}

	/**
	 * @test
	 */
	public function editActionAssignsTheGivenSubCategoryToView() {
		$subCategory = new \JS\JsTeam\Domain\Model\SubCategory();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$this->inject($this->subject, 'view', $view);
		$view->expects($this->once())->method('assign')->with('subCategory', $subCategory);

		$this->subject->editAction($subCategory);
	}

	/**
	 * @test
	 */
	public function updateActionUpdatesTheGivenSubCategoryInSubCategoryRepository() {
		$subCategory = new \JS\JsTeam\Domain\Model\SubCategory();

		$subCategoryRepository = $this->getMock('JS\\JsTeam\\Domain\\Repository\\SubCategoryRepository', array('update'), array(), '', FALSE);
		$subCategoryRepository->expects($this->once())->method('update')->with($subCategory);
		$this->inject($this->subject, 'subCategoryRepository', $subCategoryRepository);

		$this->subject->updateAction($subCategory);
	}
}
