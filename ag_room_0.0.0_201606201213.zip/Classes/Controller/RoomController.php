<?php
namespace AG\AgRoom\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 room. The TYPO3 room is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * RoomController
 */
class RoomController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * roomRepository
     *
     * @var \AG\AgRoom\Domain\Repository\RoomRepository
     * @inject
     */
    protected $roomRepository = NULL;
    
    /**
     * action list
     *
     * @param AG\AgRoom\Domain\Model\Room
     * @return void
     */
    public function listAction()
    {
        $_GP = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET();
        $post = \TYPO3\CMS\Core\Utility\GeneralUtility::_POST();
        //$postVar = \TYPO3\CMS\Core\Utility\GeneralUtility::_POST();
        $settings = $this->settings;
        $modeOptions = $settings['modeOptions'];

        if ($modeOptions == 'Room->list' || $modeOptions == 'Room->detail') {
             $uriArr = \TYPO3\CMS\Core\Utility\GeneralUtility::_GP('tx_porject_porject'); 
            if (isset($_GP['categoryID'])){
            $GLOBALS['TSFE']->additionalFooterData['gridJavascript'] = '
                <script>
                jQuery(function(){
                   jQuery("#cat_'.$_GP['categoryID'].'").click();
                });
                </script>'; 
            }
            $categoryListForGrid = $this->roomRepository->getRoomsCategory($settings);    
            $room_list = $this->roomRepository->getRooms($settings, $_GP);
            if (isset($_GP['roomID'])){
                $related_room = $this->roomRepository->relatedRoom($settings, $_GP);
                $season_price = $this->roomRepository->getSeasonablePriceOnRoom($settings, $_GP);
            }
        } elseif ($modeOptions == 'Category->list') {
            $category_list = $this->roomRepository->getRoomsCategory($settings);
        }

        if(isset($_REQUEST['anfrageID'])){
        $GLOBALS['TSFE']->additionalFooterData['modelJavascript'] = '
            <script>
            jQuery(function(){
              jQuery("#anfrageModal_'.$_REQUEST['anfrageID'].'").modal("show");
            });
            </script>'; 
        }    
            
       //  echo '<pre>';
       // print_r($room_list);
        //exit;
        //$actionUrl = $this->roomRepository->getURL($_GLOBALS['TSFE']->id);
        $actionUrl = $this->uriBuilder->getRequest()->getRequestUri();

        $this->view->assign('rooms-list', $room_list);
        $this->view->assign('category-list', $category_list);
        $this->view->assign('related_room', $related_room);
        $this->view->assign('season_price', $season_price);
        $this->view->assign('categoryListGrid', $categoryListForGrid);
        
        $this->view->assign('gp', $_GP);
        $this->view->assign('actionUrl', $actionUrl);
    }
    
    /**
     * action show
     *
     * @param AG\AgRoom\Domain\Model\Room
     * @return void
     */
    public function showAction(\AG\AgRoom\Domain\Model\Room $room)
    {
        $this->view->assign('room', $room);
    }

}