<?php

namespace AG\AgRoom\Tests\Unit\Domain\Model;

/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class \AG\AgRoom\Domain\Model\Room.
 *
 * @copyright Copyright belongs to the respective authors
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 */
class RoomTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
	/**
	 * @var \AG\AgRoom\Domain\Model\Room
	 */
	protected $subject = NULL;

	public function setUp()
	{
		$this->subject = new \AG\AgRoom\Domain\Model\Room();
	}

	public function tearDown()
	{
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function getTitleReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getTitle()
		);
	}

	/**
	 * @test
	 */
	public function setTitleForStringSetsTitle()
	{
		$this->subject->setTitle('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'title',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getSorttextReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getSorttext()
		);
	}

	/**
	 * @test
	 */
	public function setSorttextForStringSetsSorttext()
	{
		$this->subject->setSorttext('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'sorttext',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getDescriptionReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getDescription()
		);
	}

	/**
	 * @test
	 */
	public function setDescriptionForStringSetsDescription()
	{
		$this->subject->setDescription('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'description',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getImagesReturnsInitialValueForFileReference()
	{
		$this->assertEquals(
			NULL,
			$this->subject->getImages()
		);
	}

	/**
	 * @test
	 */
	public function setImagesForFileReferenceSetsImages()
	{
		$fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
		$this->subject->setImages($fileReferenceFixture);

		$this->assertAttributeEquals(
			$fileReferenceFixture,
			'images',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getFeaturesReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getFeatures()
		);
	}

	/**
	 * @test
	 */
	public function setFeaturesForStringSetsFeatures()
	{
		$this->subject->setFeatures('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'features',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getMinPersonReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getMinPerson()
		);
	}

	/**
	 * @test
	 */
	public function setMinPersonForStringSetsMinPerson()
	{
		$this->subject->setMinPerson('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'minPerson',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getMaxPersonReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getMaxPerson()
		);
	}

	/**
	 * @test
	 */
	public function setMaxPersonForStringSetsMaxPerson()
	{
		$this->subject->setMaxPerson('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'maxPerson',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getSingleRoomFeeReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getSingleRoomFee()
		);
	}

	/**
	 * @test
	 */
	public function setSingleRoomFeeForStringSetsSingleRoomFee()
	{
		$this->subject->setSingleRoomFee('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'singleRoomFee',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getExtraFeeReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getExtraFee()
		);
	}

	/**
	 * @test
	 */
	public function setExtraFeeForStringSetsExtraFee()
	{
		$this->subject->setExtraFee('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'extraFee',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getLinksReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getLinks()
		);
	}

	/**
	 * @test
	 */
	public function setLinksForStringSetsLinks()
	{
		$this->subject->setLinks('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'links',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getRoomSizeReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getRoomSize()
		);
	}

	/**
	 * @test
	 */
	public function setRoomSizeForStringSetsRoomSize()
	{
		$this->subject->setRoomSize('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'roomSize',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getMealsReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getMeals()
		);
	}

	/**
	 * @test
	 */
	public function setMealsForStringSetsMeals()
	{
		$this->subject->setMeals('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'meals',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getPriceReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getPrice()
		);
	}

	/**
	 * @test
	 */
	public function setPriceForStringSetsPrice()
	{
		$this->subject->setPrice('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'price',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getViewReturnsInitialValueForFileReference()
	{
		$this->assertEquals(
			NULL,
			$this->subject->getView()
		);
	}

	/**
	 * @test
	 */
	public function setViewForFileReferenceSetsView()
	{
		$fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
		$this->subject->setView($fileReferenceFixture);

		$this->assertAttributeEquals(
			$fileReferenceFixture,
			'view',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getAdditionalPriceInfoReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getAdditionalPriceInfo()
		);
	}

	/**
	 * @test
	 */
	public function setAdditionalPriceInfoForStringSetsAdditionalPriceInfo()
	{
		$this->subject->setAdditionalPriceInfo('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'additionalPriceInfo',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getCategoryReturnsInitialValueForCategory()
	{
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getCategory()
		);
	}

	/**
	 * @test
	 */
	public function setCategoryForObjectStorageContainingCategorySetsCategory()
	{
		$category = new \AG\AgRoom\Domain\Model\Category();
		$objectStorageHoldingExactlyOneCategory = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneCategory->attach($category);
		$this->subject->setCategory($objectStorageHoldingExactlyOneCategory);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneCategory,
			'category',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addCategoryToObjectStorageHoldingCategory()
	{
		$category = new \AG\AgRoom\Domain\Model\Category();
		$categoryObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$categoryObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($category));
		$this->inject($this->subject, 'category', $categoryObjectStorageMock);

		$this->subject->addCategory($category);
	}

	/**
	 * @test
	 */
	public function removeCategoryFromObjectStorageHoldingCategory()
	{
		$category = new \AG\AgRoom\Domain\Model\Category();
		$categoryObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$categoryObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($category));
		$this->inject($this->subject, 'category', $categoryObjectStorageMock);

		$this->subject->removeCategory($category);

	}

	/**
	 * @test
	 */
	public function getSeasonReturnsInitialValueForSeason()
	{
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getSeason()
		);
	}

	/**
	 * @test
	 */
	public function setSeasonForObjectStorageContainingSeasonSetsSeason()
	{
		$season = new \AG\AgRoom\Domain\Model\Season();
		$objectStorageHoldingExactlyOneSeason = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneSeason->attach($season);
		$this->subject->setSeason($objectStorageHoldingExactlyOneSeason);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneSeason,
			'season',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addSeasonToObjectStorageHoldingSeason()
	{
		$season = new \AG\AgRoom\Domain\Model\Season();
		$seasonObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$seasonObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($season));
		$this->inject($this->subject, 'season', $seasonObjectStorageMock);

		$this->subject->addSeason($season);
	}

	/**
	 * @test
	 */
	public function removeSeasonFromObjectStorageHoldingSeason()
	{
		$season = new \AG\AgRoom\Domain\Model\Season();
		$seasonObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$seasonObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($season));
		$this->inject($this->subject, 'season', $seasonObjectStorageMock);

		$this->subject->removeSeason($season);

	}

	/**
	 * @test
	 */
	public function getRealtedRoomsReturnsInitialValueForRoom()
	{
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getRealtedRooms()
		);
	}

	/**
	 * @test
	 */
	public function setRealtedRoomsForObjectStorageContainingRoomSetsRealtedRooms()
	{
		$realtedRoom = new \AG\AgRoom\Domain\Model\Room();
		$objectStorageHoldingExactlyOneRealtedRooms = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneRealtedRooms->attach($realtedRoom);
		$this->subject->setRealtedRooms($objectStorageHoldingExactlyOneRealtedRooms);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneRealtedRooms,
			'realtedRooms',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addRealtedRoomToObjectStorageHoldingRealtedRooms()
	{
		$realtedRoom = new \AG\AgRoom\Domain\Model\Room();
		$realtedRoomsObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$realtedRoomsObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($realtedRoom));
		$this->inject($this->subject, 'realtedRooms', $realtedRoomsObjectStorageMock);

		$this->subject->addRealtedRoom($realtedRoom);
	}

	/**
	 * @test
	 */
	public function removeRealtedRoomFromObjectStorageHoldingRealtedRooms()
	{
		$realtedRoom = new \AG\AgRoom\Domain\Model\Room();
		$realtedRoomsObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$realtedRoomsObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($realtedRoom));
		$this->inject($this->subject, 'realtedRooms', $realtedRoomsObjectStorageMock);

		$this->subject->removeRealtedRoom($realtedRoom);

	}
}
