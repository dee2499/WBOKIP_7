<?php

namespace AG\AgRoom\Tests\Unit\Domain\Model;

/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 room. The TYPO3 room is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class \AG\AgRoom\Domain\Model\Room.
 *
 * @copyright Copyright belongs to the respective authors
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 */
class RoomTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
	/**
	 * @var \AG\AgRoom\Domain\Model\Room
	 */
	protected $subject = NULL;

	public function setUp()
	{
		$this->subject = new \AG\AgRoom\Domain\Model\Room();
	}

	public function tearDown()
	{
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function getTitleReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getTitle()
		);
	}

	/**
	 * @test
	 */
	public function setTitleForStringSetsTitle()
	{
		$this->subject->setTitle('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'title',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getDescriptionReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getDescription()
		);
	}

	/**
	 * @test
	 */
	public function setDescriptionForStringSetsDescription()
	{
		$this->subject->setDescription('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'description',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getImagesReturnsInitialValueForFileReference()
	{
		$this->assertEquals(
			NULL,
			$this->subject->getImages()
		);
	}

	/**
	 * @test
	 */
	public function setImagesForFileReferenceSetsImages()
	{
		$fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
		$this->subject->setImages($fileReferenceFixture);

		$this->assertAttributeEquals(
			$fileReferenceFixture,
			'images',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getClientReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getClient()
		);
	}

	/**
	 * @test
	 */
	public function setClientForStringSetsClient()
	{
		$this->subject->setClient('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'client',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getWebsiteUrlReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getWebsiteUrl()
		);
	}

	/**
	 * @test
	 */
	public function setWebsiteUrlForStringSetsWebsiteUrl()
	{
		$this->subject->setWebsiteUrl('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'websiteUrl',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getCategoryReturnsInitialValueForCategory()
	{
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getCategory()
		);
	}

	/**
	 * @test
	 */
	public function setCategoryForObjectStorageContainingCategorySetsCategory()
	{
		$category = new \AG\AgRoom\Domain\Model\Category();
		$objectStorageHoldingExactlyOneCategory = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneCategory->attach($category);
		$this->subject->setCategory($objectStorageHoldingExactlyOneCategory);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneCategory,
			'category',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addCategoryToObjectStorageHoldingCategory()
	{
		$category = new \AG\AgRoom\Domain\Model\Category();
		$categoryObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$categoryObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($category));
		$this->inject($this->subject, 'category', $categoryObjectStorageMock);

		$this->subject->addCategory($category);
	}

	/**
	 * @test
	 */
	public function removeCategoryFromObjectStorageHoldingCategory()
	{
		$category = new \AG\AgRoom\Domain\Model\Category();
		$categoryObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$categoryObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($category));
		$this->inject($this->subject, 'category', $categoryObjectStorageMock);

		$this->subject->removeCategory($category);

	}

	/**
	 * @test
	 */
	public function getStatusReturnsInitialValueForStatus()
	{
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getStatus()
		);
	}

	/**
	 * @test
	 */
	public function setStatusForObjectStorageContainingStatusSetsStatus()
	{
		$statu = new \AG\AgRoom\Domain\Model\Status();
		$objectStorageHoldingExactlyOneStatus = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneStatus->attach($statu);
		$this->subject->setStatus($objectStorageHoldingExactlyOneStatus);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneStatus,
			'status',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addStatuToObjectStorageHoldingStatus()
	{
		$statu = new \AG\AgRoom\Domain\Model\Status();
		$statusObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$statusObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($statu));
		$this->inject($this->subject, 'status', $statusObjectStorageMock);

		$this->subject->addStatu($statu);
	}

	/**
	 * @test
	 */
	public function removeStatuFromObjectStorageHoldingStatus()
	{
		$statu = new \AG\AgRoom\Domain\Model\Status();
		$statusObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$statusObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($statu));
		$this->inject($this->subject, 'status', $statusObjectStorageMock);

		$this->subject->removeStatu($statu);

	}

	/**
	 * @test
	 */
	public function getRealtedRoomsReturnsInitialValueForRoom()
	{
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getRealtedRooms()
		);
	}

	/**
	 * @test
	 */
	public function setRealtedRoomsForObjectStorageContainingRoomSetsRealtedRooms()
	{
		$realtedRoom = new \AG\AgRoom\Domain\Model\Room();
		$objectStorageHoldingExactlyOneRealtedRooms = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneRealtedRooms->attach($realtedRoom);
		$this->subject->setRealtedRooms($objectStorageHoldingExactlyOneRealtedRooms);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneRealtedRooms,
			'realtedRooms',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addRealtedRoomToObjectStorageHoldingRealtedRooms()
	{
		$realtedRoom = new \AG\AgRoom\Domain\Model\Room();
		$realtedRoomsObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$realtedRoomsObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($realtedRoom));
		$this->inject($this->subject, 'realtedRooms', $realtedRoomsObjectStorageMock);

		$this->subject->addRealtedRoom($realtedRoom);
	}

	/**
	 * @test
	 */
	public function removeRealtedRoomFromObjectStorageHoldingRealtedRooms()
	{
		$realtedRoom = new \AG\AgRoom\Domain\Model\Room();
		$realtedRoomsObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$realtedRoomsObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($realtedRoom));
		$this->inject($this->subject, 'realtedRooms', $realtedRoomsObjectStorageMock);

		$this->subject->removeRealtedRoom($realtedRoom);

	}
}
