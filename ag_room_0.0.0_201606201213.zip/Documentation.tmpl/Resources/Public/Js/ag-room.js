

$(function(){
	$(".portfolio-grid .btn-porto").click(function(){
		$(".portfolio-grid .btn-porto").removeClass('btn-default').addClass('btn-small');
		$(this).addClass('btn-default').removeClass('btn-small');
		var _data_target = $(this).attr('data-tg');			
		if(_data_target == 'all'){
			$(".room-listing").fadeIn();
		}else{
			$(".room-listing").fadeOut();
		}	
		$(".room-listing").each(function(){
			var _data_tar = $(this).attr('data-show');
			if(_data_tar.indexOf(_data_target) != -1){
			    $(this).fadeIn();
			}
		});
	});

});

