

jQuery(document).ready(function() {
	if(jQuery('li.current').length == 1){
		jQuery('.f3-widget-paginator').remove();
	}
});

jQuery(function(){


	jQuery(".product-grid .btn-product").click(function(){
		jQuery(".product-grid .btn-product").removeClass('btn-default').addClass('btn-small');
		jQuery(this).addClass('btn-default').removeClass('btn-small');
		var _data_target = jQuery(this).attr('data-tg');			
		if(_data_target == 'all'){
			jQuery(".product-list").fadeIn();
		}else{
			jQuery(".product-list").fadeOut();
		}	
		jQuery(".product-list").each(function(){
			var _data_tar = jQuery(this).attr('data-show');
			if(_data_tar.indexOf(_data_target) != -1){
			   jQuery(this).fadeIn();
			}
		});
	});
});
