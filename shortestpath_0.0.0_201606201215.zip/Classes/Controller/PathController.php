<?php
namespace Pj\Shortestpath\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * PathController
 */
class PathController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * pathRepository
	 *
	 * @var \Pj\Shortestpath\Domain\Repository\PathRepository
	 * @inject
	 */
	protected $pathRepository = NULL;

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {

		$currentUrl = $this->uriBuilder->getRequest()->getRequestUri();

		if (isset($_POST['lan'])) {
            $msg['currentCity']    = $this->getCurrentLocation('city'); 
            $msg['CurrentCountry'] = $this->getCurrentLocation('country');
            $msg['CurrentLat']     = $this->getCurrentLocation('lat');
            $msg['CurrentLng']     = $this->getCurrentLocation('lon');

            $msg['val_enter_dest_value']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_shortestpath_domain_model_path.val_enter_dest_value','shortestpath');
            $msg['distance']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_shortestpath_domain_model_path.distance','shortestpath');
            $msg['duration']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_shortestpath_domain_model_path.duration','shortestpath');
            $msg['val_error']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_shortestpath_domain_model_path.val_error','shortestpath');
            $msg['total_distance']= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_shortestpath_domain_model_path.total_distance','shortestpath');
            
            echo json_encode($msg);
            die;
        }

        $data['currentCity']    = $this->getCurrentLocation('city'); 
        $data['CurrentCountry'] = $this->getCurrentLocation('country');
        $data['CurrentLat']     = $this->getCurrentLocation('lat');
        $data['CurrentLng']     = $this->getCurrentLocation('lon');


		//$paths = $this->pathRepository->findAll();
		
		$this->view->assignMultiple(array(
              'locates'      => $locates,
              'data'   		 => $data,              
              'settings'     => $this->settings,
              'currentUrl'   => $currentUrl
        ));
	}

	public function getCurrentLocation($para){
        
      $ip = $_SERVER['REMOTE_ADDR']; 
      $data = @unserialize(file_get_contents('http://ip-api.com/php/'.$ip));

      if($data && $data['status'] == 'success') {
       return $data[$para];
      }else{     
        if($para=='city'){
            $data['city']='Graz';
        }else if($para == 'countryCode'){
             $data['countryCode']='Austria';
        }else if($para == 'lat'){
             $data['lat']='47.516231';
        }else if($para == 'lon'){
             $data['lon']='14.550072';
        }else{

        }
     return $data[$para];        
      }   
   }

}