
$(document).ready(function(){      
    $.ajax({  
        type: "POST",  
        url:$('#shortest-path-form').attr('action'),
        data:"lan=1", 
        global: false,
        async:false,    
        success: function(response){
            response = JSON.parse(response);
            retVal = response;
        }
    }); 

});

        var source, destination;
        var directionsDisplay;
        var directionsService = new google.maps.DirectionsService();
        google.maps.event.addDomListener(window, 'load', function () {
            new google.maps.places.SearchBox(document.getElementById('txtSource'));
            new google.maps.places.SearchBox(document.getElementById('txtDestination'));
            directionsDisplay = new google.maps.DirectionsRenderer({ 'draggable': true });
        });

        function GetRoute() {
             var val = document.getElementById('txtDestination').value;
                if (/^\s*$/.test(val)){
                    $('#ajax_msg').html("<p class='alert alert-block alert-error fade in'>"+retVal.val_enter_dest_value+"</p>").fadeIn();
                    return false;
            }

            var mumbai = new google.maps.LatLng(18.9750, 72.8258);
            var mapOptions = {
                zoom: 7,
                center: mumbai
            };
            map = new google.maps.Map(document.getElementById('dvMap'), mapOptions);
            directionsDisplay.setMap(map);
            directionsDisplay.setPanel(document.getElementById('dvPanel'));

            //*********DIRECTIONS AND ROUTE**********************//
            source = document.getElementById("txtSource").value;
            destination = document.getElementById("txtDestination").value;

            var request = {
                origin: source,
                destination: destination,
                provideRouteAlternatives:true,
                travelMode: google.maps.TravelMode.DRIVING
            };
            directionsService.route(request, function (response, status) {
                if (status == google.maps.DirectionsStatus.OK) {
                    directionsDisplay.setDirections(response);
                    computeTotalDistance(0,response);
                    theroute=response;
                }
            });

            //*********DISTANCE AND DURATION**********************//
            var service = new google.maps.DistanceMatrixService();
            service.getDistanceMatrix({
                origins: [source],
                destinations: [destination],
                travelMode: google.maps.TravelMode.DRIVING,
                unitSystem: google.maps.UnitSystem.METRIC,
                avoidHighways: false,
                avoidTolls: false
            }, function (response, status) {
                if (status == google.maps.DistanceMatrixStatus.OK && response.rows[0].elements[0].status != "ZERO_RESULTS") {
                    var distance = response.rows[0].elements[0].distance.text;
                    var duration = response.rows[0].elements[0].duration.text;
                    var dvDistance = document.getElementById("dvDistance");
                    dvDistance.innerHTML = "";
                    dvDistance.innerHTML += " <p class='alert alert-success'> "+retVal.distance+ " " + distance + "<br />" + retVal.duration+ " " + duration + "</p> " ;

                } else {
                     $('#ajax_msg').html("<p class='alert alert-block alert-error fade in'> "+ retVal.val_error +"</p>").fadeIn();
                }
            });
            
        }

        function computeTotalDistance(idx, rsp) {
            if (rsp){this.rsp=rsp;
                google.maps.event.addListener(directionsDisplay, 'routeindex_changed', function() {
                    computeTotalDistance(directionsDisplay.getRouteIndex());
                });
            }
            var total = 0;
            var myroute = this.rsp.routes[idx];
            for (i = 0; i < myroute.legs.length; i++) {
                total += myroute.legs[i].distance.value;
            }
            var km =(Math.round(total/1000) + "km");
            $('#ajax_msg').html("<p class='alert alert-success fade in'> " + retVal.total_distance +km+"</p>").fadeIn();

        }

        setTimeout(function(){
         var val = document.getElementById('txtDestination').value;
            if (/^\s*$/.test(val)){
               return true; 
            }
            else{
               document.getElementById('getRoute').click();
            }
        }, 3000);

