<?php
namespace Maunil\Newsletter\Domain\Repository;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Maunil <montu1555@gmail.com>, Worlds technologies
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Newsletters
 */
use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \Maunil\Newsletter\Service\MailTemplate;
use \Maunil\Newsletter\Service\HtmlTags;
class NewsletterRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{

	public function findemail($useremail,$settings,$getmethodsData,$actionUrl){


			$to 			= $useremail['email'];
			$from 			= $settings['senderEmail'];
			$subject 		= $settings['senderSubject'];
			$mailName 		= $settings['senderName'];
			$userMessage	= $settings['userMessage'];
			//for Admin mail
  			$admin_mail		= $settings['receiverEmail'];
			$from_admin 		= $settings['receiverEmail'];
			$subject_admin 	= $settings['receiverSubject'];
			$mailName_admin 	= $settings['receiverName'];
			$email_message 	= $settings['adminMessage'];

			$fields = '*';
			$table = 'tt_address';

			$insertfield = array('email' => $useremail['email'],'pid' => $settings['storageFolder'],'hidden' => $useremail['hidden'],'module_sys_dmail_html' => $useremail['module_sys_dmail_html']);

						
			$Admin_message = nl2br(str_replace('{name}', $useremail['email'], $settings['adminMessage']));

			$where = 'deleted = 0 and pid = '.$settings['storageFolder'].' AND email = "'.$useremail['email'].'" ';
			
			$res = $GLOBALS['TYPO3_DB']->exec_SELECTquery($fields,$table,$where);
			$numofraws = $GLOBALS['TYPO3_DB']->sql_num_rows($res);
			//$numofraws = count($res);
			
					if($numofraws == 0){	
						// $in = $GLOBALS['TYPO3_DB']->INSERTQuery($table,$insertfield);
						$insert = $GLOBALS['TYPO3_DB']->exec_INSERTquery($table,$insertfield);
						$lastInsertId = $GLOBALS['TYPO3_DB']->sql_insert_id();								
						$getRecord = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($fields,$table,'uid='.$lastInsertId);

						if($insert){
							
							if($settings['sendToReceiver'] == 1) {
								$sendToReceiver = $this->sendEmails($admin_mail,$from_admin,$subject_admin,$Admin_message,$mailName_admin); // mail to Receiver	
							}
							$approveUrl = $actionUrl.'?act=1&subscribeID='.base64_encode($getRecord[0]['uid']); 

        					//$deleteUrl = $actionUrl.'?del=1&subscribeID='.base64_encode($getRecord[0]['uid']);
						
							$mailcontent = "<table><tr><td>Hello $to</td></tr><tr><td><a href='$approveUrl'>If you want to activate newsletter subscription then click here</a></td></tr></table>";
							
							$sendEmails = $this->sendEmails($to,$from,$subject,$mailcontent,$mailName);
							if($sendEmails){
								return 1;
								header("Location:".$actionUrl);
							}
						}	
					}
					if($numofraws > 0){
						return -2;
						header("Location:".$actionUrl);
					}
	}

	public function changeStatus($uid,$settings,$useremail,$actionUrl){	
		$table = 'tt_address';
		$where = 'uid  = '.$uid;
	
		$res = $GLOBALS['TYPO3_DB']->exec_SELECTgetSingleRow('*',$table,$where);
		
		if($res['hidden'] == 1){

				$updateArr = array(
					'hidden'	=> 0,
				);
				$update = $GLOBALS['TYPO3_DB']->exec_UPDATEquery($table,'uid='.$uid,$updateArr);
					if($update){
						
						$mailcontent	= $settings['userMessage'];

						$confirmEmails = $this->sendEmails($res['email'],$settings['senderEmail'],$settings['senderSubject'],$mailcontent,$settings['senderName']); // mail to User
						//$confirmEmails = $this->sendEmails($to,$from,$subject,$userMessage,$mailName);
						if($confirmEmails){
							return 4;
							header("Location:".$actionUrl); 
						}
					}

		}else{
			return 6;
		}
	}
	public function unsubscribeEmail($settings,$useremail,$unsubemail,$actionUrl){
		$fields = '*';
		$table = 'tt_address';
		//$where = "";
		$where = 'pid = '.$settings['storageFolder'].' AND email = "'.$unsubemail.'" ';
		//$res = $GLOBALS['TYPO3_DB']->SELECTquery($fields,$table,$where);
		$res1 = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($fields,$table,$where);
		

		if($res1[0]['email'] == $unsubemail){
			

					$table = 'tt_address';
					$wheredel = 'deleted = 0 and pid = '.$settings['storageFolder'].' AND email = "'.$unsubemail.'" ';
					// $del = $GLOBALS['TYPO3_DB']->DELETEquery($table,$wheredel);
					$res = $GLOBALS['TYPO3_DB']->exec_SELECTgetSingleRow('*',$table,$wheredel);
					$del = $GLOBALS['TYPO3_DB']->exec_DELETEquery($table,$wheredel);
					
					if($del){

						$mailcontent1 = nl2br(str_replace('{email}', $useremail['email'], $settings['userUnsubscribeMessage']));
						
						$unsubscribeEmails = $this->sendEmails($res['email'],$settings['senderEmail'],$settings['senderSubject'],$mailcontent1,$settings['senderName']);

						if($unsubscribeEmails){
							return -3;
							header("Location:".$actionUrl);
						}
					}
		}else{
			return 5;
		}

	}

	function sendEmails($recipient,$sender_email,$subject,$mailcontent,$mailName){
		$mail = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Mail\\MailMessage');
		$mail->setFrom($sender_email);							
		$mail->setFrom(array($sender_email => $mailName));				
		$mail->setTo($recipient);
		$mail->setSubject($subject);
		$mail->setBody($mailcontent, 'text/html');
		return $mail->send();
		
	}

}