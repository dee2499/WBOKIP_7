<?php
namespace Maunil\Newsletter\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Maunil <montu1555@gmail.com>, Worlds technologies
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * NewsletterController
 */
class NewsletterController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * newsletterRepository
     *
     * @var \Maunil\Newsletter\Domain\Repository\NewsletterRepository
     * @inject
     */
    protected $newsletterRepository = NULL;
    
    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        //$newsletters = $this->newsletterRepository->findAll();
       

            $GLOBALS["TSFE"]->set_no_cache();

            $actionUrl = $this->request->getBaseUri(); //$this->uriBuilder->getRequest()->getRequestUri(); 
            $getmethodsData = $_GET;
            $settings = $this->settings;
            $useremail = $_POST;

            if (isset($_GET['subscribeID'])) {
                
                $sid = intVal(base64_decode($_GET['subscribeID']));
                
                if($sid>0){
                    $findemail = $this->newsletterRepository->changeStatus($sid,$settings,$useremail,$actionUrl);
                }
            }
            if(isset($_GET['actionurl']) && !empty($_POST['email'])) {
           
                $unsubemail = $_POST['email'];

                $msg  = $this->newsletterRepository->unsubscribeEmail($settings,$useremail,$unsubemail,$actionUrl);
            }
        
            if(isset($_POST['submit'])){
           
               $findemail = $this->newsletterRepository->findemail($useremail,$settings,$getmethodsData,$actionUrl);
               
            } 
      
            $this->view->assign('eMsg', $msg);
            $this->view->assign('emailMsg', $findemail);
            $this->view->assign('settings', $settings);
            $this->view->assign('actionUrl', $actionUrl);
            $this->view->assign('getmethodsData', $getmethodsData);
}

}