// $(function(){
//   $('#followbtn').on('click', function(e){
//     e.preventDefault();
//     $('#followbtn').fadeOut(300);

//     $.ajax({
//       url: 'index.php/list',
//       type: 'post',
//       data: {'action': 'follow', 'userid': '11239528343'},
//       success: function(data, status) {
//         if(data == "ok") {
//           $('#followbtncontainer').html('<p><em>you are successfully subscribe!</em></p>');
//           var numfollowers = parseInt($('#followercnt').html()) + 1;
//           $('#followercnt').html(numfollowers);
//         }else{
//           $('#followbtncontainer').html('<p><em>Email is alredy exist </em></p>');
//           var numfollowers = parseInt($('#followercnt').html()) + 1;
//           $('#followercnt').html(numfollowers);
//         }

//       },
//       error: function(xhr, desc, err) {
//         console.log(xhr);
//         console.log("Details: " + desc + "\nError:" + err);
//       }
//     }); // end ajax call
//   });



$(function(){
    if($('p').hasClass('subscribed_newsletter')){
        $('html, body').scrollTop($(document).height()-$(window).height());
    }
});

function get_email(){
    var e1 = 'Please enter a valid e-mail address !';
    var  emailStr =  jQuery.trim(document.getElementById("ag_email").value);

    var regex = /^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i;
    
     if( regex.test(emailStr) ){
             jQuery('.error_email').text('');
             return true;
     }else{

            jQuery('.error_email').text(e1).css({ 'color':'red' });
            return false;   
    }
}

/* Form validation */
function validateFields(){
    var e = 'This field is required';
    if( get_email() ){
        return true;
    }else{
        jQuery('.errors').text(e).css({ 'color':'red' });       
        get_email();
        return false;
    }
}


/* Edit Email Form validation */
function validateEmailFields(){
    var e = 'Das ist ein Pflichtfeld';
    if( get_email() ){
        return true;
    }else{
        jQuery('.errors').text(e).css({ 'color':'red' });       
        get_email();        
        return false;
    }
}

