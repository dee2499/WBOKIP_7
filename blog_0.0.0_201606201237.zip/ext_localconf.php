<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'WOI.' . $_EXTKEY,
	'Blog',
	array(
		'Post' => 'listView, detailView, extraView1, extraView2, list, searchForm, searchList',
		
	),
	// non-cacheable actions
	array(
		'Post' => 'listView, detailView, extraView1, extraView2, list, searchForm, searchList',
	)
);
