function socialsharing_twitter_click(message)
{
	if (typeof message === 'undefined')
		message = encodeURIComponent(location.href);
		window.open('https://twitter.com/intent/tweet?text=' + message , 'sharertwt', 'toolbar=0,status=0,width=640,height=445');
	}

function socialsharing_facebook_click(message)
{
	window.open('https://www.facebook.com/sharer.php?u=' + encodeURIComponent(location.href)+'&v=1', 'sharer', 'toolbar=0,status=0,width=660,height=445');
}

function socialsharing_google_click(message)
{
	window.open('https://plus.google.com/share?url=' + document.location.href + '&data-prefilltext=' + message, 'sharergplus', 'toolbar=0,status=0,width=660,height=445');
	
	
}

$(document).ready(function() {
  $('#filterOptions li a').click(function() {
    // fetch the class of the clicked item
    var ourClass = $(this).attr('class');

    // reset the active class on all the buttons
    $('#filterOptions li').removeClass('active');
    // update the active state on our clicked button
    $(this).parent().addClass('active');

    if(ourClass == 'all') {
      // show all our items
      $('#ourHolder').children('div.item').show();
    }
    else {
      // hide all elements that don't share ourClass
      $('#ourHolder').children('div:not(.' + ourClass + ')').hide();
      // show all elements that do share ourClass
      $('#ourHolder').children('div.' + ourClass).show();
    }
    return false;
  });
});

$(document).ready(function() {
    var location = window.location.href;
$("#linkeBtn").removeAttr("disabled");
$("#unlinkeBtn").removeAttr("disabled");
$('#linkeBtn').one("click", function(e)
    {
        var val = parseInt($("#linkeBtn").val(), 10);
        $.post(location, {op:"like"},function(data)
        {   
            var dataArray = data.split("_");
            if(dataArray[0]==1)
            {
                
                val = val+1;
                $("#linkeBtn").val(val);
                $("#linkeBtn").attr("value", dataArray[1]);
                $("#linkeBtn").attr("disabled", "disabled");
                $("#font").removeClass( "glyphicon glyphicon-thumbs-up" );
                $("#font").addClass( "fa fa-thumbs-up" );
            }
            else
            {
                $("#status").html("Already Liked!!");
                $("#linkeBtn").attr("value", dataArray[1]);
            }
        })
    });
});


function checkValidEmail(field) {
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!filter.test(field.val())) {
            return false;
        }
        return true;
    }
    
    function validatePhone(field) {
           
        var filter = /^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/;
        
        if (!filter.test(field.val())) {
            return false;
        }
        return true;
    }


    function validate(id) {

        var flag = 0;
             
        jQuery("#"+id+" .validate").removeClass("error");
        
        jQuery("#"+id+" .validate").each(function(){
            if(jQuery(this).val()==''){
                jQuery(jQuery(this)).addClass("error");
                jQuery(this).attr("placeholder",jQuery(this).attr('mendatory_message'));
                flag = 1;
            } 
        });

        if(jQuery("#"+id+" .email.validate").length  >  0){

            var email = jQuery("#"+id+" .email");
            if(email.val()!=""){
                if(!checkValidEmail(email)) {
                    email.attr("placeholder",email.attr('valid_message'));
                    jQuery("#"+id+" .email").val("").addClass("error");
                    flag = 1;
                }
            }
        }
        

        if(jQuery("#"+id+" .phone.validate").length  >  0){
            
            var phone = jQuery("#"+id+" .phone");
            if(phone.val()!=""){
                if(!validatePhone(phone)) {
                    phone.attr("placeholder",phone.attr('valid_message'));
                    jQuery("#"+id+" .phone").val("").addClass("error");
                    flag = 1;
                }
            }
        }
        
        
        if(flag == 0) { 
            return true;
        }else {
            //alert("Bitte füllen Sie alle erforderlichen Felder aus.");
            return false;
        }
    }

    function trim(field){
        return jQuery.trim(field.val());    
    }    

jQuery(document).ready(function() {

    jQuery(".validate").blur(function(){
        if(trim(jQuery(this))!=""){
            jQuery(this).removeClass("error");
        }else{
            if(jQuery(this).hasClass("email")){
                jQuery(this).addClass("error");
                jQuery(this).attr("placeholder",jQuery(this).attr('valid_message'));
            }else{
                jQuery(this).addClass("error");
                jQuery(this).attr("placeholder",jQuery(this).attr('mendatory_message'));
                jQuery(this).val("");
            }
        }
    })
    
    jQuery(".validate").keyup(function(){
        
        if(trim(jQuery(this))!=""){
            jQuery(this).removeClass("error");
        }else{
            jQuery(this).addClass("error");
        }
    })
    
    jQuery(".email.validate").blur(function(){
        
        var email = jQuery(this);

        if(email.val()!=""){
            if(!checkValidEmail(email)) {
                //alert(email.attr('valid_message'));
                email.attr("placeholder",email.attr('valid_message'));
                jQuery(this).addClass("error").val("").focus();
            }
        }
    })
});

$(document).ready(function(){
        $('.row').each(function(){
        var highestBox = 0;
        $('.w-title', this).each(function(){
            if($(this).height() > highestBox)
                highestBox = $(this).height();
            });
        $('.w-title',this).height(highestBox);
    });
        
});