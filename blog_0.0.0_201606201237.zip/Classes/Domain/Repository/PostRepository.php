<?php
namespace WOI\Blog\Domain\Repository;

use TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Posts
 */
class PostRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {
	
	public function listViewData($currentBljCat,$settings) {

		
		$pid = $settings['storage'];


		$catID = $settings['Cat_requiredFields'];
		//$where = 'deleted = 0 AND hidden = 0 AND sys_language_uid IN (-1, '.$GLOBALS['TSFE']->sys_language_uid.') AND category IN ('.$catID.')';
		if(isset($_GET['cat'])){
			$where = 'deleted = 0 AND hidden = 0 AND sys_language_uid IN (-1, '.$GLOBALS['TSFE']->sys_language_uid.') AND pid = '.$pid.' AND category = '.$_GET['cat'];	
		}else{
			$where = 'deleted = 0 AND hidden = 0 AND sys_language_uid IN (-1, '.$GLOBALS['TSFE']->sys_language_uid.') AND pid = '.$pid.' AND category IN ('.$catID.')';
		}
		//echo $GLOBALS['TYPO3_DB']->SELECTquery('*','tx_blog_domain_model_post', ''.$where.'', '', 'uid DESC', ''); die;
		$res = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*','tx_blog_domain_model_post', ''.$where.'', '', 'uid DESC', '');
			/*echo "<pre>";
			print_r($res);
			die;*/

		if(count($res)>0){
			for($i=0; $i<count($res); $i++){
				$p[$i]['uid']			=	$res[$i]['uid'];
				$p[$i]['post_title']	=	$res[$i]['post_title'];
				$p[$i]['image']			=	$res[$i]['image'];
				$p[$i]['description']	=	$res[$i]['description'];
				$p[$i]['rating']		=	$res[$i]['rating'];
				$p[$i]['date']			= 	gmdate("d/m/Y", $res[$i]['date']);
				$p[$i]['time1']			= 	gmdate("H:i a", $res[$i]['date']);
				$p[$i]['time']			=   date("g:i a", strtotime($p[$i]['time1']));
				$p[$i]['author']		=	$res[$i]['author'];
				$p[$i]['category']		=	$res[$i]['category'];
				$p[$i]['dateCheck']		=	$res[$i]['dateCheck'];
				$p[$i]['timeCheck']		=	$res[$i]['timeCheck'];
				$p[$i]['authorCheck']	=	$res[$i]['authorCheck'];
				$p[$i]['categoryCheck']	=	$res[$i]['categoryCheck'];
				$p[$i]['ratingCheck']	=	$res[$i]['ratingCheck'];
				$p[$i]['liker']			=	$res[$i]['likecounter'];
				$p[$i]['preview_image']	=	$res[$i]['pre_image'];
				$p[$i]['preview_desc']	=	$res[$i]['pre_description'];
			}
		}
		return $p;
	}

	public function detailCheck($uid,$settings) {
		
		$where = 'uid ='.$uid.' AND deleted = 0 AND hidden = 0 AND sys_language_uid IN 	(-1, '.$GLOBALS['TSFE']->sys_language_uid.')';
		
		$res	=	$GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*','tx_blog_domain_model_post', ''.$where.'', '', 'uid DESC', '');
		
		if(count($res)>0){
			for($i=0; $i<count($res); $i++){
				$p[$i]['uid']			=	$res[$i]['uid'];
				$p[$i]['post_title']	=	$res[$i]['post_title'];
				$p[$i]['image']			=	$res[$i]['image'];
				$p[$i]['description']	=	$res[$i]['description'];
				$p[$i]['rating']		=	$res[$i]['rating'];
			if($res[$i]['date'] > 0){
				$p[$i]['date']			= 	gmdate("d/m/Y", $res[$i]['date']);
				$p[$i]['time1']			= 	gmdate("H:i:s", $res[$i]['date']);
			}
				$p[$i]['time']			=   date("g:i a", strtotime($p[$i]['time1']));
				$p[$i]['author']		=	$res[$i]['author'];
				$p[$i]['category']		=	$res[$i]['category'];
				$p[$i]['dateCheck']		=	$res[$i]['DdateCheck'];
				$p[$i]['timeCheck']		=	$res[$i]['DtimeCheck'];
				$p[$i]['authorCheck']	=	$res[$i]['DauthorCheck'];
				$p[$i]['categoryCheck']	=	$res[$i]['DcategoryCheck'];
				$p[$i]['ratingCheck']	=	$res[$i]['DratingCheck'];
				$p[$i]['currentUri']	= 	'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

				if (isset($GLOBALS["TSFE"]->fe_user->user["uid"])){
					$p[$i]['logged'] = $GLOBALS["TSFE"]->fe_user->user["uid"];;
				}
				if (isset($settings['loginpage'])){
					$p[$i]['loginpage'] = $settings['loginpage'];
				}
			}
		}
		foreach ($p as $key => $value) {
			$np = $value;
		}
		return $np;
	}
	
	public function saveCmtData($actionUrl, $conf = array() ) {
		$flag		=	0;
		$today		=	time();
		$pid		=	$conf['detailpage'];
		
		if(empty($conf['detailpage'])){
			$pid	=	1;
		}
		$id			=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('id');
		$blgid		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('blgid');
		$ctitle		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('ctitle');
		$cname		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('cname');
		$cemail		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('cemail');
		$ccmt		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('ccmt');
		$btncmt		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('btncmt');
		$score		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('cscore');	
		$cruserid	=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('cruserid');
		
		if($cemail!= ''){
			$insArr  = array(
								'pid' 				=> $pid,
								'tstamp'			=> time(),
								'crdate'			=> time(),
								'deleted' 			=> 0,
								'hidden' 			=> 0,
								
								//'comment_title'		=> $ctitle,
								//'approved' 			=> 0,
								'approved' 			=> 1,
								'date' 				=> $today,
								'post' 				=> $blgid,
								'name' 				=> $cname,
								'email' 			=> $cemail,
								'comment_details'	=> $ccmt,
								'score'				=> 1,	
								'userid'			=> $cruserid,
								'sys_language_uid'  => $GLOBALS['TSFE']->sys_language_uid 
								
						);
			$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;		
			//echo $GLOBALS['TYPO3_DB']->INSERTquery('tx_blog_domain_model_comment', $insArr); die;
			$GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_blog_domain_model_comment', $insArr);
			$parent = $GLOBALS['TYPO3_DB']->sql_insert_id();
			$insArr  =	array( 	
					'score'		=> $score = $score!=""?$score:"",
					'users'		=> $GLOBALS["TSFE"]->fe_user->user["uid"] ,
					'parent' 	=> $parent,
					'tstamp'	=> time(),
					'crdate' 	=> time(),
					'pid'		=> 99,
					'comment'   => $parent,
					'post'   => $blgid,
			);
			$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
			//echo $GLOBALS['TYPO3_DB']->INSERTquery('tx_blog_domain_model_commentscore', $insArr); die;
			$GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_blog_domain_model_commentscore', $insArr);
			$lastUID = $GLOBALS['TYPO3_DB']->sql_insert_id();
			$updateCount	=	$this->updateCmtCount($blgid);
			$flag	=	1;							
		}		
		header("Location:".$actionUrl."#comment-".$lastUID);
		die;
	}
	
	public function updateCmtCount($bid) {
		
		$where	='deleted = 0 AND hidden = 0 AND uid = '.$bid.' AND sys_language_uid IN (-1,'.$GLOBALS['TSFE']->sys_language_uid.')';
		//echo $GLOBALS['TYPO3_DB']->SELECTquery('comment_count','tx_blog_domain_model_post', ''.$where.'', '', '', ''); die;
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTgetRows('comment_count','tx_blog_domain_model_post', ''.$where.'', '', '', '');

		if(empty($res[0]['comment_count'])){
			$count	=	0;
		}else{
			$count	=	$res[0]['comment_count'];
		}
		$updateArr  =	array( 'comment_count'		=> ($count+1)	);
		$where 		=	'uid = '.$bid. '';					
		$GLOBALS['TYPO3_DB']->exec_UPDATEquery('tx_blog_domain_model_post', ''.$where.'', $updateArr);
		return true;
		
	}
	
	public function getCmts($bid) {
		$where	=' comment.deleted = 0 AND comment.hidden = 0 AND comment.post = '.$bid.' AND comment.approved=1 AND comment.sys_language_uid IN (-1,'.$GLOBALS['TSFE']->sys_language_uid.')';
		$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
		// echo $GLOBALS['TYPO3_DB']->SELECTquery(
		// 		'comment.*,group_concat(commentscore.score) as scoreOrg',
		// 		'tx_blog_domain_model_comment as comment LEFT JOIN tx_blog_domain_model_commentscore as commentscore ON (commentscore.parent = comment.uid)', 
		// 		''.$where.'', 'comment.uid', '', ''); die;
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
				'comment.*,group_concat(commentscore.score) as scoreOrg',
				'tx_blog_domain_model_comment as comment LEFT JOIN tx_blog_domain_model_commentscore as commentscore ON (commentscore.parent = comment.uid)', 
				''.$where.'', 'comment.uid', '', '');
		if(count($res)>0){
			for($i=0; $i<count($res); $i++){
				$p[$i]['uid']				=	$res[$i]['uid'];
				$p[$i]['comment_title']		=	$res[$i]['comment_title'];
				$p[$i]['name']				=	$res[$i]['name'];
				$p[$i]['email']				=	$res[$i]['email'];
				$p[$i]['comment_details']	=	$res[$i]['comment_details'];		
				$p[$i]['date']				=	$res[$i]['date'];
				$p[$i]['approved']			=	$res[$i]['approved'];
				$p[$i]['post']				=	$res[$i]['post'];
				$p[$i]['score']				=	$res[$i]['scoreOrg'];							
			}
		}
		return $p;		
	}

	public function getLastBlogId() {
		$where	='deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTgetRows('uid','tx_blog_domain_model_post', ''.$where.'', '', 'uid DESC', '0,1');
		return $res[0]['uid'];	
	}	

	public function saveCmtReplyData($actionUrl, $conf = array() ) {


		$flag		=	0;
		$today		=	time();
		$pid		=	$conf['detailpage'];
		//$pid		=	$conf['storage'];
		
		if(empty($conf['detailpage'])){
			$pid	=	1;
		}
	
		$id					=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('id');
		$blgid				=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('blgid');
		$ctitle				=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('crtitle');
		$cname				=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('crname');
		$cemail				=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('cremail');
		$ccmt				=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('crcmt');
		$crcmtid			=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('crcmtid');
		$score				=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('crscore');	
		$parentcmtid		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('parentcmtid');
		$cruserid			=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('cruserid');
		
		if($cemail!= ''){
			$insArr  = array(
								'pid' 				=> $pid,
								'tstamp'			=> time(),
								'crdate'			=> time(),
								'deleted' 			=> 0,
								'hidden' 			=> 0,
								
								//'replycomment_title'	=> $ctitle,
								//'approved' 			=> 0,
								'approved' 			=> 1,
								'date' 				=> $today,
								'post' 				=> $blgid,
								'comment'           => $crcmtid,
								'name' 				=> $cname,
								'email' 			=> $cemail,
								'replycomment_details'	=> $ccmt,
								'score'				=> (!empty($score)) ? $score : 0 ,	
								'parent_comment'	=> $parentcmtid	,
								'userid'			=> $cruserid
								
						);
			$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;		
			//echo $GLOBALS['TYPO3_DB']->INSERTquery('tx_blog_domain_model_replytocomment', $insArr); die;
			$GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_blog_domain_model_replytocomment', $insArr);
			$parent = $GLOBALS['TYPO3_DB']->sql_insert_id();
			$insArr1  =	array(
					'score'		=> $score,
					'users'		=> $GLOBALS["TSFE"]->fe_user->user["uid"] ,
					'parent' 	=> $parent,
					'tstamp'	=> time(),
					'crdate' 	=> time(),
					'pid'		=> 99
			);
			$GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_blog_domain_model_replycommentscore', $insArr1);
			$flag	=	1;							
		}		
		header("Location:".$actionUrl."#comment-".$parent);
		die;
	}
	
	public function getReplytoCmts($bid , $parent ) {

		$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
		$where	='comment.deleted = 0 AND comment.hidden = 0 AND comment.comment = '.$bid.' AND comment.parent_comment = '.$parent.'  AND comment.approved=1 AND comment.sys_language_uid IN (-1, '.$GLOBALS['TSFE']->sys_language_uid.')';
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTgetRows('comment.*,group_concat(commentscore.score) as scoreOrg','tx_blog_domain_model_replytocomment as comment LEFT JOIN  tx_blog_domain_model_replycommentscore as commentscore ON (commentscore.parent = comment.uid)', ''.$where.'', 'comment.uid', '', '');
		if(count($res)>0){
			for($i=0; $i<count($res); $i++){
				
				$p[$i]['uid']				=	$res[$i]['uid'];
				$p[$i]['comment_title']		=	$res[$i]['replycomment_title'];
				$p[$i]['name']				=	$res[$i]['name'];
				$p[$i]['email']				=	$res[$i]['email'];
				$p[$i]['comment_details']	=	$res[$i]['replycomment_details'];
				$p[$i]['date']				=	$res[$i]['date'];
				$p[$i]['approved']			=	$res[$i]['approved'];
				$p[$i]['post']				=	$res[$i]['post'];
				$p[$i]['score']				=	$res[$i]['scoreOrg'];
				$p[$i]['parent_comment']	=	$res[$i]['parent_comment'];
				$p[$i]['comment']			=	$res[$i]['comment'];
			}
		}
		return $p;
	}
	
	public function updateScore($configId , $score , $post ) {
		//echo $GLOBALS["TSFE"]->fe_user->user["uid"];
		if ( !empty($GLOBALS["TSFE"]->fe_user->user["uid"])){
			$tableRcd = array("replycommentscore"=>"tx_blog_domain_model_replycommentscore","commentscore" => "tx_blog_domain_model_commentscore" );
			$configArray = explode("-",$configId) ;
			$table = $tableRcd[$configArray[0]];
			$where	='users = '.$GLOBALS["TSFE"]->fe_user->user["uid"].' AND parent = '.$configArray[1];
			$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
			$res	=$GLOBALS['TYPO3_DB']->exec_SELECTcountRows('*',$table, ''.$where.'');
			if( !empty($res) ){
				return 0;
			}
			switch ($table){
				case 'tx_blog_domain_model_commentscore' :
					$insArr  =	array( 	'score'		=> $score	,
							'users'		=> $GLOBALS["TSFE"]->fe_user->user["uid"] ,
							'parent' 	=> $configArray[1],
							'comment'	=> $configArray[1],
							'post'		=> $post,
							'tstamp'	=> time(),
							'crdate' 	=> time(),
							'pid'		=> 99
					);
					$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
					$GLOBALS['TYPO3_DB']->exec_INSERTquery($table, $insArr);
					break;
				case 'tx_blog_domain_model_replycommentscore' :
					$insArr  =	array( 	'score'		=> $score	,
							'users'		=> $GLOBALS["TSFE"]->fe_user->user["uid"] ,
							'parent' 	=> $configArray[1],
							'tstamp'	=> time(),
							'crdate' 	=> time(),
							'pid'		=> 99
					);
					$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
					$GLOBALS['TYPO3_DB']->exec_INSERTquery($table, $insArr);
					break;
					
			}
			return 1;
		}else{
			return -1;
		}
		
	}
	
	public function isAlreadyCommented( $userId , $commentid , $post) {
		
		$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
		
		if($userId && $userId!=''){
			$where	='userid = '.$userId.'  AND parent_comment =  0 AND post =  '.$post.' AND deleted = 0 AND hidden = 0 AND sys_language_uid = '.$GLOBALS['TSFE']->sys_language_uid.'';
		}else {
			$where	='parent_comment =  0 AND post =  '.$post.' AND deleted = 0 AND hidden = 0 AND sys_language_uid = '.$GLOBALS['TSFE']->sys_language_uid.'';
		}
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTcountRows('uid','tx_blog_domain_model_replytocomment', ''.$where.'', '', 'uid DESC', '0,1');
		return $res;
	}
	
	
	public function isAlreadyReplyed( $userId , $commentid ) {
		$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
		if($userId && $userId!=''){
			$where	='userid = '.$userId.'  AND parent_comment = '.$commentid.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		}else {
			$where	='parent_comment = '.$commentid.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		}

		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTcountRows('uid','tx_blog_domain_model_replytocomment', ''.$where.'', '', 'uid DESC', '0,1');
		return $res;
	}
	
	public function isAlreadyScored( $userId , $comment ) {
		if($userId && $userId!=''){
			$where	='users = '.$userId.'  AND comment = '.$comment.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		}else {
			$where	='comment = '.$comment.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		}
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTcountRows('uid','tx_blog_domain_model_commentscore', ''.$where.'', '', 'uid DESC', '0,1');
		return $res;
	}
	
	public function isAlreadyScoredForReply( $userId , $comment ) {
		$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;

		if($userId && $userId!=''){
		$where	='users = '.$userId.'  AND parent = '.$comment.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		}else {
		$where	='parent = '.$comment.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		}
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTcountRows('uid','tx_blog_domain_model_replycommentscore', ''.$where.'');
		return $res;
	}
	
	public function isAlreadyScoredForReplyAlt( $userId , $comment ) {
		$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
		if($userId && $userId!=''){
			$where	='users = '.$userId.'  AND uid = '.$comment.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		}else {
			$where	='uid = '.$comment.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		}
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTcountRows('uid','tx_blog_domain_model_replycommentscore', ''.$where.'');
		return $res;
	}

	public function getCat($settings) {
	
		
		$catID = $settings['Cat_requiredFields'];


		$fields = '*';

		$where	=' deleted = 0 AND hidden = 0 AND sys_language_uid IN (-1, '.$GLOBALS['TSFE']->sys_language_uid.') AND uid IN ('.$catID.')';

		//echo $res = $GLOBALS['TYPO3_DB']->SELECTquery($fields,'tx_blog_domain_model_category', ''.$where.'');die;
		$res = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($fields,'tx_blog_domain_model_category', ''.$where.'');
		
		return $res;

		
		
	}
	public function catActive() {
		if(isset($_GET['cat'])){
			$data = $_GET['cat'];
		}else{
			$data = "all";
		}
		return $data;
		
		
	}
	/**
	*
	*@param $uid
	* 
	*/
	public function findNext($uid) {
		
		$fields = '*';
		$table = 'tx_blog_domain_model_post';
	    $where = 'deleted = 0 AND hidden = 0 AND sys_language_uid = ' . $GLOBALS['TSFE']->sys_language_uid.' AND uid >'.$uid;

	    //$where = 'deleted = 0 AND hidden = 0 AND uid >'.$uid;
	    $res = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($fields, $table, $where,'','uid',1); 
	    return $res[0]['uid'];
	}
	public function findPrev($uid) {
		$fields = '*';
		$table = 'tx_blog_domain_model_post';
	    $where = 'deleted = 0 AND hidden = 0 AND sys_language_uid = ' . $GLOBALS['TSFE']->sys_language_uid.' AND uid <'.$uid;

	    //$where = 'deleted = 0 AND hidden = 0 AND uid <'.$uid;
	    //echo $res = $GLOBALS['TYPO3_DB']->SELECTquery($fields, $table, $where,'','uid',1); die;
	    $res = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($fields, $table, $where,'','uid',1); 
	    return $res[0]['uid'];
	}

	public function findAllSearchResults($keywoed){	



		$date = new \DateTime('today');
		$org_date = $date->format('Y-m-d');
		$str_date = strtotime($org_date);	
		$Query = $this->createQuery();


		$arr1 = GeneralUtility::trimExplode(' ', $keywoed, true);

		$whr = $whr1 = $whr2 = array();

		foreach ($arr1 as $key => $value) {
			$whr[] = " ( tc.bodytext LIKE '%".$value."%' OR  p.title LIKE '%".$value."%' ) ";
			$whr1[] = " ( description LIKE '%".$value."%' OR post_title LIKE '%".$value."%') ";
			$whr2[] = " ( description LIKE '%".$value."%' OR title LIKE '%".$value."%') ";
		}

		$Query->statement("
(SELECT p.uid,p.title,tc.bodytext as description,'page' as 'type', 'pages' as 'table' FROM pages as p
INNER JOIN tt_content as tc ON p.uid=tc.pid 
WHERE ( ".implode(' OR ', $whr)." )

AND p.no_search=0 AND p.hidden=0 AND p.deleted=0
AND p.nav_hide=0
AND p.doktype != 254
AND tc.hidden=0 AND tc.deleted=0
AND sys_language_uid =".$GLOBALS['TSFE']->sys_language_uid."
GROUP BY p.uid)

UNION

(SELECT uid,post_title,description as description, 'blog' as 'type','tx_blog_domain_model_post' as 'table' FROM tx_blog_domain_model_post
WHERE  ( ".implode(' OR ', $whr1)." )
AND hidden=0 AND deleted=0
AND sys_language_uid IN (-1, ".$GLOBALS['TSFE']->sys_language_uid.")
GROUP BY uid)


UNION

(SELECT uid,title,description as description, 'portfolio' as 'type','tx_portfolio_domain_model_portfolio' as 'table' FROM tx_portfolio_domain_model_portfolio
WHERE  ( ".implode(' OR ', $whr2)." )
AND hidden=0 AND deleted=0
AND sys_language_uid IN (-1,".$GLOBALS['TSFE']->sys_language_uid.")
GROUP BY uid
)"); 
		return $Query->execute(TRUE);
		
	}	

}