<?php
namespace WOI\Blog\Domain\Model;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Post
 */
class Post extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * postTitle
	 * 
	 * @var string
	 */
	protected $postTitle = '';

	/**
	 * description
	 * 
	 * @var string
	 */
	protected $description = '';

	/**
	 * image
	 * 
	 * @var string
	 */
	protected $image = '';

	/**
	 * date
	 * 
	 * @var \DateTime
	 */
	protected $date = NULL;

	/**
	 * allowComments
	 * 
	 * @var string
	 */
	protected $allowComments = '';

	/**
	 * commentCount
	 * 
	 * @var string
	 */
	protected $commentCount = '';

	/**
	 * category
	 * 
	 * @var \WOI\Blog\Domain\Model\Category
	 */
	protected $category = NULL;

	/**
	 * author
	 * 
	 * @var \WOI\Blog\Domain\Model\User
	 */
	protected $author = NULL;

	/**
	 * Returns the postTitle
	 * 
	 * @return string $postTitle
	 */
	public function getPostTitle() {
		return $this->postTitle;
	}

	/**
	 * Sets the postTitle
	 * 
	 * @param string $postTitle
	 * @return void
	 */
	public function setPostTitle($postTitle) {
		$this->postTitle = $postTitle;
	}

	/**
	 * Returns the description
	 * 
	 * @return string $description
	 */
	public function getDescription() {
		return $this->description;
	}

	/**
	 * Sets the description
	 * 
	 * @param string $description
	 * @return void
	 */
	public function setDescription($description) {
		$this->description = $description;
	}

	/**
	 * Returns the image
	 * 
	 * @return string $image
	 */
	public function getImage() {
		return $this->image;
	}

	/**
	 * Sets the image
	 * 
	 * @param string $image
	 * @return void
	 */
	public function setImage($image) {
		$this->image = $image;
	}

	/**
	 * Returns the date
	 * 
	 * @return \DateTime $date
	 */
	public function getDate() {
		return $this->date;
	}

	/**
	 * Sets the date
	 * 
	 * @param \DateTime $date
	 * @return void
	 */
	public function setDate(\DateTime $date) {
		$this->date = $date;
	}

	/**
	 * Returns the allowComments
	 * 
	 * @return string $allowComments
	 */
	public function getAllowComments() {
		return $this->allowComments;
	}

	/**
	 * Sets the allowComments
	 * 
	 * @param string $allowComments
	 * @return void
	 */
	public function setAllowComments($allowComments) {
		$this->allowComments = $allowComments;
	}

	/**
	 * Returns the commentCount
	 * 
	 * @return string $commentCount
	 */
	public function getCommentCount() {
		return $this->commentCount;
	}

	/**
	 * Sets the commentCount
	 * 
	 * @param string $commentCount
	 * @return void
	 */
	public function setCommentCount($commentCount) {
		$this->commentCount = $commentCount;
	}

	/**
	 * Returns the category
	 * 
	 * @return \WOI\Blog\Domain\Model\Category $category
	 */
	public function getCategory() {
		return $this->category;
	}

	/**
	 * Sets the category
	 * 
	 * @param \WOI\Blog\Domain\Model\Category $category
	 * @return void
	 */
	public function setCategory(\WOI\Blog\Domain\Model\Category $category) {
		$this->category = $category;
	}

	/**
	 * Returns the author
	 * 
	 * @return \WOI\Blog\Domain\Model\User $author
	 */
	public function getAuthor() {
		return $this->author;
	}

	/**
	 * Sets the author
	 * 
	 * @param \WOI\Blog\Domain\Model\User $author
	 * @return void
	 */
	public function setAuthor(\WOI\Blog\Domain\Model\User $author) {
		$this->author = $author;
	}

}