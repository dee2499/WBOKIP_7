<?php
namespace WOI\Blog\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * PostController
 */
class PostController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * postRepository
	 * 
	 * @var \WOI\Blog\Domain\Repository\PostRepository
	 * @inject
	 */
	protected $postRepository = NULL;

	/**
	 * action list
	 * 
	 * @return void
	 */
	public function listAction() {
		$posts = $this->postRepository->findAll();
		$this->view->assign('posts', $posts);
	}

	/**
	 * action listView
	 * 
	 * @return void
	 */
	public function listViewAction() {
		if(!empty($this->settings['blogcategory'])){
			$listView = $this->postRepository->listViewData($this->settings['blogcategory']);
			
			foreach ($listView as $key => $value) {
				$blgid = $value['uid'];
				$Cmtdetail[$blgid] = $this->postRepository->getCmts($blgid);				
				$listView[$key]['cat'] = $this->postRepository->findByUid($blgid);
				//$BlgDetail[$blgid] = $this->postRepository->findByUid($blgid);

			}
			foreach ($Cmtdetail as $key => $value) {
				$count[$key] = count($value);
			}
			foreach ($listView as $key => $value) {
				 
				$listView[$key]['count'] = $count[$value['uid']];
			}
			$getCat	= $this->postRepository->getCat();
			$catActive	= $this->postRepository->catActive();

			$this->view->assign('catActive', $catActive);
			$this->view->assign('getCat', $getCat);
			$this->view->assign('listView', $listView);
			$this->view->assign('Cmtdetail', $Cmtdetail);
			$this->view->assign('Blgdetail', $BlgDetail);
			$this->includeAdditionalData();			

		}			
	}

	/**
	 * action detailView
	 * 
	 * @return void
	 */
	public function detailViewAction() {
		$listView = $this->postRepository->listViewData($this->settings['blogcategory']);
			foreach ($listView as $key => $value) {
				$rating = $value['rating'];
				$this->view->assign('rating', $rating);		
			}
		$GLOBALS['TSFE']->set_no_cache();
			$this->includeAdditionalData();
		if(!empty($_POST['action'])){
			$result = $this->postRepository->updateScore( $_REQUEST['source'] ,$_REQUEST['value'] ,  $_GET['blgid'] );
			echo $result;
			exit;
		}
		
		if($_POST['btncmt']){
		//	echo '<pre>';print_r($this->settings);echo '</pre>';	die;
			$this->postRepository->saveCmtData( $this->settings );			
		}	
		if($_POST['btnrecmt']){
			$this->postRepository->saveCmtReplyData( $this->settings );	
		}
		
		if($_GET['blgid'] && $_GET['blgid']!='' && $_GET['blgid'] > 0){

			$blgDetail 		= $this->postRepository->findByUid($_GET['blgid']);
			$detailCheck 		= $this->postRepository->detailCheck($_GET['blgid'],$this->settings);
			$getcmtsDetail	= $this->postRepository->getCmts($_GET['blgid']);
			$this->ogData($_GET['blgid']);
			$likeCounter = $this->likeCounter($_GET['blgid']);
			
		if(count($getcmtsDetail)>0){
				
				foreach ( $getcmtsDetail as $key => $comments ){
					if( !empty($comments['score']) ){
						$count = count(explode(',',$comments['score']));
						$sumRecds = array_sum(explode(',',$comments['score']));
						$getcmtsDetail[$key]['score'] = ( ($sumRecds/$count) > 5 ) ? 5 : ($sumRecds/$count);
						//echo $alreadyScored = $this->postRepository->isAlreadyScored($GLOBALS["TSFE"]->fe_user->user["uid"],$comments['uid'] );
						$getcmtsDetail[$key]['alreadyscore'] = !empty( $alreadyScored ) ? False : TRUE;
					}
					//echo $GLOBALS["TSFE"]->fe_user->user["uid"];  die; 
					$alreadyCommented = $this->postRepository->isAlreadyCommented($GLOBALS["TSFE"]->fe_user->user["uid"],$_GET['blgid'],$_GET['blgid']);
					//$getcmtsDetail[$key]['showReplyBox']  =  !empty( $alreadyCommented) ? false : true;
					$getcmtsDetail[$key]['showReplyBox']  =  TRUE;
					
					if ( !empty($this->postRepository->getReplytoCmts($comments['uid'],0 ) ) )
						$getcmtsDetail[$key]['reply'] = $this->postRepository->getReplytoCmts($comments['uid'] , 0);
				}
			
				foreach ( $getcmtsDetail as $key => $comments ){
					if ( $getcmtsDetail[$key]['reply'] )
						foreach ( $getcmtsDetail[$key]['reply'] as $innerkey => $replyComments ){
						if( !empty($replyComments['score']) ){
							$count = count(explode(',',$replyComments['score']));
							$sumRecds = array_sum(explode(',',$replyComments['score']));
							$getcmtsDetail[$key]['reply'][$innerkey]['score'] = ( round($sumRecds/$count) > 5 ) ? 5 : round($sumRecds/$count);
						}
						$alreadyScored = $this->postRepository->isAlreadyScoredForReply($GLOBALS["TSFE"]->fe_user->user["uid"],$replyComments['uid'] );
						$getcmtsDetail[$key]['reply'][$innerkey]['alreadyscore'] = !empty( $alreadyScored ) ? TRUE : FALSE;
						$alreadyReplied  = $this->postRepository->isAlreadyReplyed($GLOBALS["TSFE"]->fe_user->user["uid"],$replyComments['uid']);
						//$getcmtsDetail[$key]['reply'][$innerkey]['showReplyBox'] =  !empty( $alreadyReplied) ? false : true;
						$getcmtsDetail[$key]['reply'][$innerkey]['showReplyBox'] =  TRUE;
						$getcmtsDetail[$key]['reply'][$innerkey]['innercommet'] = $this->postRepository->getReplytoCmts($comments['uid'] , $replyComments['uid']);
						
						//echo "<pre>";print_r($getcmtsDetail[$key]['reply'][$innerkey]['innercommet']);
						
						if( !empty($getcmtsDetail[$key]['reply'][$innerkey]['innercommet'])){
							foreach ( $getcmtsDetail[$key]['reply'][$innerkey]['innercommet'] as $key1 => $value ){
								$alreadyScored = $this->postRepository->isAlreadyScoredForReply($GLOBALS["TSFE"]->fe_user->user["uid"],$value['uid'] );
								$getcmtsDetail[$key]['reply'][$innerkey]['innercommet'][$key1]['alreadyscore'] = !empty( $alreadyScored ) ? TRUE : FALSE;
								
								if( !empty($value['score']) ){
									$count = count(explode(',',$value['score']));
									$sumRecds = array_sum(explode(',',$value['score']));
									$getcmtsDetail[$key]['reply'][$innerkey]['innercommet'][$key1]['score'] = ( ($sumRecds/$count) > 5 ) ? 5 : ($sumRecds/$count);
								}
							}
						}
					}
				}
			}
		
			//echo "<pre>";print_r($getcmtsDetail);exit;
			// $loggedin = !empty( $GLOBALS["TSFE"]->fe_user->user["uid"] ) ? TRUE : FALSE; 
			$loggedin = 1; 
			$alreadyCommented = $this->postRepository->isAlreadyCommented($GLOBALS["TSFE"]->fe_user->user["uid"],$_GET['blgid'],$_GET['blgid']);
			
			//$showCommentBox = ( $alreadyCommented==1) ? false : true;
			$showCommentBox = true;
			$this->view->assign('showCommentBox', $showCommentBox);
			$this->view->assign('name', $GLOBALS["TSFE"]->fe_user->user['name']);
			$this->view->assign('email', $GLOBALS["TSFE"]->fe_user->user['email']);
			$this->view->assign('uid', $GLOBALS["TSFE"]->fe_user->user["uid"]);
			$this->view->assign('loggedin', $loggedin);
			$this->view->assign('blgDetail', $blgDetail);
			$this->view->assign('detailCheck', $detailCheck);
			$this->view->assign('getcmtsDetail', $getcmtsDetail);
			
		}else{
			$latestBlgId	=	$this->postRepository->getLastBlogId();
			$blgDetail 		= $this->postRepository->findByUid($latestBlgId);
			$getcmtsDetail	= $this->postRepository->getCmts($latestBlgId);
			
			$this->view->assign('blgDetail', $blgDetail);
			$this->view->assign('detailCheck', $detailCheck);
			$this->view->assign('getcmtsDetail', $getcmtsDetail);
			
				
		}		
	}


	/**
	 * includeAdditionalData
	 *
	 * @return
	 */
	function includeAdditionalData() {
		
		$additionalfooterData = '
		<script src="typo3conf/ext/blog/Resources/Public/Scripts/jquery.raty.js" type="text/javascript"></script>
		<script src="typo3conf/ext/blog/Resources/Public/Scripts/share.js" type="text/javascript"></script>
		<script src="typo3conf/ext/blog/Resources/Public/Scripts/blog_common.js" type="text/javascript"></script>';
	 	$additionalheaderData .= '
	 	<link rel="stylesheet" href="typo3conf/ext/blog/Resources/Public/Scripts/style.css" type="text/css" media="all" />';
		$GLOBALS['TSFE']->additionalFooterData['9996'] = $additionalfooterData;
		$GLOBALS['TSFE']->additionalHeaderData['9669'] = $additionalheaderData;

	}

	/**
	 * ogData
	 *
	 * @return
	 */
	function ogData($id) {
		
		$where = 'uid = '.$id.' AND deleted = 0 AND hidden = 0 AND sys_language_uid IN(-1, '.$GLOBALS['TSFE']->sys_language_uid.')';	

		$res = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*','tx_blog_domain_model_post', ''.$where.'', '', 'uid DESC', '');
		
		//echo $GLOBALS['TYPO3_DB']->SELECTquery('*','tx_blog_domain_model_post', ''.$where.'', '', 'uid DESC', ''); die;

		if(count($res)>0){
			for($i=0; $i<count($res); $i++){
				$p[$i]['uid']			=	$res[$i]['uid'];
				$p[$i]['post_title']	=	$res[$i]['post_title'];
				$p[$i]['image']			=	$res[$i]['image'];
				$p[$i]['description']	=	$res[$i]['description'];
				
			}
		}
		foreach ($p as $key => $value) {
			$p1 = $value;
		}
		
		$additionalheaderData = '
	 	<meta property="og:title" content="'.$p1['post_title'].'">
		<meta property="og:image" content="http://typo3.weboffice.co.at/typo3_7/uploads/tx_blog/'.$p1['image'].'">
		<meta property="og:description" content="'.$p1['description'].'">
		
		<meta name="twitter:card" content="summary_large_image">
		<meta name="twitter:title" content="'.$p1['post_title'].'">
		<meta name="twitter:image:src" content="http://typo3.weboffice.co.at/typo3_7/uploads/tx_blog/'.$p1['image'].'">
		<meta name="twitter:description" content="'.$p1['description'].'">';

		$GLOBALS['TSFE']->additionalHeaderData['969'] = $additionalheaderData;
	}

	/**
	 * likeCounter
	 *
	 * @return
	 */
	function likeCounter($id) {	
		
		$where = 'uid = '.$id.' AND deleted = 0 AND hidden = 0 AND sys_language_uid IN(-1, '.$GLOBALS['TSFE']->sys_language_uid.')';	

		$res = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('likecounter','tx_blog_domain_model_post', ''.$where.'', '', 'uid DESC', '');
		// echo"<pre>";
		// print_r($res);
		// die;
		$liker = $res[0]['likecounter'];

		$this->view->assign('liker', $liker);	
		if(isset($_COOKIE["blog_".$id]))
			    {	
			    	$token = 1;
			    	$this->view->assign('token', $token);
			    }
		//echo $GLOBALS['TYPO3_DB']->SELECTquery('uid,likecounter','tx_blog_domain_model_post', ''.$where.'', '', 'uid DESC', ''); die;
		if($_POST['op']){

			if(count($res)>0){
				
				$like = $res[0]['likecounter'];

			    if(isset($_COOKIE["blog_".$id]))
			    {	
			    	$token = 1;
			    	$this->view->assign('token', $token);
			        $data = "-1_".$like;
			        echo $data;
			        exit;
			    }

			    setcookie("blog_".$id, "liked", time()+3600*24);
			    if($_POST['op'] == 'like')
			    {
			        $like = $like+1;
			    }
			    
			    $updateArray = array('likecounter' => $like);

			    $result = $GLOBALS['TYPO3_DB']->exec_UPDATEquery ('tx_blog_domain_model_post','uid = '.$id,$updateArray, TRUE);
			    //echo $GLOBALS['TYPO3_DB']->UPDATEquery ('tx_blog_domain_model_post','uid = '.$id,$updateArray, TRUE);
			    //echo "$like";
			    //print_r($updateArray);
			    	$data = "1_".$like;
			    	echo $data;
			    exit;   
			}
			
		}
	}


	/**
	 * action extraView1
	 * 
	 * @return void
	 */
	public function extraView1Action() {
		
	}

	/**
	 * action extraView2
	 * 
	 * @return void
	 */
	public function extraView2Action() {
		
	}

}