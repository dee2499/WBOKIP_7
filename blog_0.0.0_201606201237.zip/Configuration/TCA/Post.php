<?php
if (!defined ('TYPO3_MODE')) {
	die ('Access denied.');
}

$GLOBALS['TCA']['tx_blog_domain_model_post'] = array(
	'ctrl' => $GLOBALS['TCA']['tx_blog_domain_model_post']['ctrl'],
	'interface' => array(
		'showRecordFieldList' => 'sys_language_uid, l10n_parent, l10n_diffsource, hidden, post_title, pre_description, description, pre_image, image, date, allow_comments, comment_count, category, author, dateCheck, timeCheck, authorCheck, categoryCheck, DdateCheck, DtimeCheck, DauthorCheck, DcategoryCheck',
	),
	'types' => array(
		'1' => array('showitem' => 'sys_language_uid;;;;1-1-1, l10n_parent, l10n_diffsource, hidden;;1, category, author, post_title, pre_description;;;richtext:rte_transform[mode=ts_links], description;;;richtext:rte_transform[mode=ts_links], pre_image, image, date, allow_comments, comment_count,  --div--;LLL:EXT:cms/locallang_ttc.xlf:tabs.access, starttime, endtime, --div--;List Page, categoryCheck, authorCheck, dateCheck, timeCheck, --div--;Detail Page, DcategoryCheck, DauthorCheck, DdateCheck, DtimeCheck,'),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(
	
		'sys_language_uid' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.language',
			'config' => array(
				'type' => 'select',
				'renderType' => 'selectSingle',
				'foreign_table' => 'sys_language',
				'foreign_table_where' => 'ORDER BY sys_language.title',
				'items' => array(
					array('LLL:EXT:lang/locallang_general.xlf:LGL.allLanguages', -1),
					array('LLL:EXT:lang/locallang_general.xlf:LGL.default_value', 0)
				),
			),
		),
		'l10n_parent' => array(
			'displayCond' => 'FIELD:sys_language_uid:>:0',
			'exclude' => 1,
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.l18n_parent',
			'config' => array(
				'type' => 'select',
				'items' => array(
					array('', 0),
				),
				'foreign_table' => 'tx_blog_domain_model_post',
				'foreign_table_where' => 'AND tx_blog_domain_model_post.pid=###CURRENT_PID### AND tx_blog_domain_model_post.sys_language_uid IN (-1,0)',
			),
		),
		'l10n_diffsource' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),

		't3ver_label' => array(
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.versionLabel',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'max' => 255,
			)
		),
	
		'hidden' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
			'config' => array(
				'type' => 'check',
			),
		),
		'starttime' => array(
			'exclude' => 1,
			'l10n_mode' => 'mergeIfNotBlank',
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.starttime',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0,
				'range' => array(
					'lower' => mktime(0, 0, 0, date('m'), date('d'), date('Y'))
				),
			),
		),
		'endtime' => array(
			'exclude' => 1,
			'l10n_mode' => 'mergeIfNotBlank',
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.endtime',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0,
				'range' => array(
					'lower' => mktime(0, 0, 0, date('m'), date('d'), date('Y'))
				),
			),
		),

		'post_title' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.post_title',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'pre_description' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.pre_description',
			'config' => array(
				'type' => 'text',
				'cols' => 40,
				'rows' => 15,
				'eval' => 'trim'
			),
			'defaultExtras' => 'richtext[]'
		),
		'description' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.description',
			'config' => array(
				'type' => 'text',
				'cols' => 40,
				'rows' => 15,
				'eval' => 'trim'
			),
			'defaultExtras' => 'richtext[]'
		),
		'pre_image' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.pre_image',
			'config' => array(
				'type' => 'group',
				'internal_type' => 'file',
				'allowed' => 'gif,jpg,jpeg,png',
				'max_size' => $GLOBALS['TYPO3_CONF_VARS']['BE']['maxFileSize'],
				'uploadfolder' => 'uploads/tx_blog',
				'show_thumbs' => 1,
				'size' => 1,
				'minitems' => 0,
				'maxitems' => 1,
			),
		),
		'image' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.image',
			'config' => array(
				'type' => 'group',
				'internal_type' => 'file',
				'allowed' => 'gif,jpg,jpeg,png',
				'max_size' => $GLOBALS['TYPO3_CONF_VARS']['BE']['maxFileSize'],
				'uploadfolder' => 'uploads/tx_blog',
				'show_thumbs' => 1,
				'size' => 1,
				'minitems' => 0,
				'maxitems' => 1,
			),
		),
		'date' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.date',
			'config' => array(
				'type' => 'input',
				'size' => 7,
				'eval' => 'date',
				'checkbox' => 1,
				'default' => time()
			),
		),
		'allow_comments' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.allow_comments',
			'config' => array(
					'type' => 'check'
			),
		),
		'comment_count' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.comment_count',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim',
				'readOnly' => 1
			),
		),
		'category' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.category',
			'config' => array(
				'type' => 'select',
				'renderType' => 'selectSingle',
				'foreign_table' => 'tx_blog_domain_model_category',
				'minitems' => 0,
				'maxitems' => 1,
			),
		),
		'author' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.author',
			'config' => array(
				'type' => 'select',
				'renderType' => 'selectSingle',
				'foreign_table' => 'tx_blog_domain_model_user',
				'minitems' => 0,
				'maxitems' => 1,
			),
		),
		'rating' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.rating',
			'config' => array(
            'type' => 'select',
            'renderType' => 'selectSingle',
            'allowNonIdValue' => true,
            'items' => array(
					array('0', 0),
 					array('1', 1),
    				array('2', 2),
    				array('3', 3),
    				array('4', 4),
    				array('5', 5),
				),
			'minitems' => 0,
			'maxitems' => 1,
            'foreign_field' => 'catlabel'
        	),
		),
		'ratingCheck' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.ratingCheck',
			'config' => array(
				'type' => 'check',
			),
		),
		'dateCheck' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.dateCheck',
			'config' => array(
				'type' => 'check',
			),
		),
		'timeCheck' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.timeCheck',
			'config' => array(
				'type' => 'check',
			),
		),
		'authorCheck' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.authorCheck',
			'config' => array(
				'type' => 'check',
			),
		),
		'categoryCheck' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.categoryCheck',
			'config' => array(
				'type' => 'check',
			),
		),

		'DratingCheck' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.ratingCheck',
			'config' => array(
				'type' => 'check',
			),
		),
		'DdateCheck' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.dateCheck',
			'config' => array(
				'type' => 'check',
			),
		),
		'DtimeCheck' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.timeCheck',
			'config' => array(
				'type' => 'check',
			),
		),
		'DauthorCheck' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.authorCheck',
			'config' => array(
				'type' => 'check',
			),
		),
		'DcategoryCheck' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:blog/Resources/Private/Language/locallang_db.xlf:tx_blog_domain_model_post.categoryCheck',
			'config' => array(
				'type' => 'check',
			),
		),
		
	),
);
